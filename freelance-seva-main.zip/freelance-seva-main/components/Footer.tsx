import Link from "next/link";
import { Mail, MapPin, Phone, Facebook, Instagram, Linkedin, Youtube, Rocket } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-white border-t-4 border-zinc-950 text-zinc-950 mt-24">
      {/* Main Footer Navigation columns */}
      <div className="bg-slate-50/50">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 grid gap-12 grid-cols-1 sm:grid-cols-2 lg:grid-cols-12">

          {/* Brand/Bio Column */}
          <div className="lg:col-span-4 flex flex-col items-start">
            <div className="flex items-center gap-2 font-doodle font-black text-2xl text-zinc-950">
              <Rocket className="w-6 h-6 text-zinc-950 rotate-[-15deg] animate-pulse" />
              Freelance<span className="text-white px-3 py-0.5 bg-zinc-950 rotate-[-2deg] shadow-[2px_2px_0px_rgba(0,0,0,0.15)]">Seva</span>
            </div>
            <p className="text-slate-600 text-sm font-semibold mt-4 max-w-sm leading-relaxed">
              An AI-powered digital marketing and web design agency helping startups and SMBs grow online — faster, smarter, and bespoke at every single step.
            </p>

            {/* Outlined Socials */}
            <div className="flex gap-4 mt-6">
              {[
                { Icon: Facebook, label: "Facebook" },
                { Icon: Instagram, label: "Instagram" },
                { Icon: Linkedin, label: "Linkedin" },
                { Icon: Youtube, label: "Youtube" },
              ].map(({ Icon, label }) => (
                <a key={label} href="#" aria-label={label} className="relative grid place-items-center w-10 h-10 border-2 border-zinc-950 bg-white text-zinc-950 rounded-full shadow-[2px_2px_0px_#09152e] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 transition-all duration-300 hover:bg-zinc-950 hover:text-white">
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Explore Links */}
          <div className="lg:col-span-2">
            <h4 className="font-doodle font-black text-xl text-zinc-950 mb-4 tracking-wide uppercase">Explore</h4>
            <ul className="space-y-2 text-sm font-semibold text-slate-600">
              {["Services", "Work", "Blog", "Pricing"].map((item) => (
                <li key={item}>
                  <Link
                    href={item === "Work" ? "/portfolio" : `/${item.toLowerCase()}`}
                    className="hover:text-zinc-950 transition-colors"
                  >
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services Links */}
          <div className="lg:col-span-3">
            <h4 className="font-doodle font-black text-xl text-zinc-950 mb-4 tracking-wide uppercase">Services</h4>
            <ul className="space-y-2 text-sm font-semibold text-slate-600">
              {[
                "Website Design & Development",
                "E-Commerce Solutions",
                "SEO Services",
                "Social Media Marketing",
                "Google & Meta Ads",
                "Logo & Brand Identity",
                "E-Commerce Management",
              ].map((service) => (
                <li key={service} className="hover:text-zinc-950 cursor-pointer transition-colors">
                  {service}
                </li>
              ))}
            </ul>
          </div>

          {/* Get In Touch / Contact Column */}
          <div className="lg:col-span-3">
            <h4 className="font-doodle font-black text-xl text-zinc-950 mb-4 tracking-wide uppercase">Get In Touch</h4>
            <ul className="space-y-4 text-sm font-semibold text-slate-600">
              <li className="flex items-start gap-3">
                <span className="relative grid place-items-center w-8 h-8 border border-zinc-950 bg-amber-100 text-zinc-950 rounded-lg shadow-[1.5px_1.5px_0px_rgba(0,0,0,1)] shrink-0 mt-0.5 select-none pointer-events-none">
                  <MapPin className="w-4 h-4 z-10" />
                </span>
                <span className="leading-relaxed">
                  Zakir Nagar, Okhla, New Delhi-110025
                </span>
              </li>
              <li className="flex items-center gap-3">
                <span className="relative grid place-items-center w-8 h-8 border border-zinc-950 bg-amber-100 text-zinc-950 rounded-lg shadow-[1.5px_1.5px_0px_rgba(0,0,0,1)] shrink-0 select-none pointer-events-none">
                  <Mail className="w-4 h-4 z-10" />
                </span>
                <a href="mailto:info@freelanceseva.com" className="hover:text-zinc-950 transition-colors break-all">
                  info@freelanceseva.com
                </a>
              </li>
              <li className="flex items-start gap-3">
                <span className="relative grid place-items-center w-8 h-8 border border-zinc-950 bg-amber-100 text-zinc-950 rounded-lg shadow-[1.5px_1.5px_0px_rgba(0,0,0,1)] shrink-0 mt-0.5 select-none pointer-events-none">
                  <Phone className="w-4 h-4 z-10" />
                </span>
                <div className="flex flex-col gap-1">
                  <a href="tel:+916397801840" className="hover:text-zinc-950 transition-colors">+91 6397801840</a>
                  <a href="tel:+919027166138" className="hover:text-zinc-950 transition-colors">+91 9027166138</a>
                  <a href="tel:+918077128072" className="hover:text-zinc-950 transition-colors">+91 8077128072</a>
                </div>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom copyright block */}
        <div className="border-t-2 border-zinc-950 py-6 text-center text-xs font-semibold text-slate-500 bg-white">
          © {new Date().getFullYear()} FreelanceSeva. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
