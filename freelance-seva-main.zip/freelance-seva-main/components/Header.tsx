"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";
import { Menu, X, Rocket, ShoppingBag, Globe, Smartphone, Laptop, ChevronDown, Megaphone, Share2, Search, TrendingUp, Palette } from "lucide-react";

const linksBefore = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/services", label: "Services" },
] as const;

const linksAfter = [
  { to: "/contact", label: "Contact" },
] as const;

const developmentMenu = [
  {
    title: "Shopify",
    icon: ShoppingBag,
    items: [
      "Shopify Web Designing",
      "Shopify Web Development",
      "Shopify Discovery Audit",
      "Shopify Store Migration",
      "Shopify Marketing",
      "PSD to Shopify",
      "Shopify Priority Support",
    ],
  },
  {
    title: "Open Source",
    icon: Globe,
    items: [
      "Woo Commerce",
      "Opencart",
      "Magento",
      "Ecommerce Website Development",
    ],
  },
  {
    title: "App Development",
    icon: Smartphone,
    items: [
      "iOS App development",
      "Android App development",
      "Flutter App Development",
      "React Native App Development",
      "Ecommerce App Development",
      "OTT App Development",
    ],
  },
  {
    title: "WordPress Development",
    icon: Laptop,
    items: [
      "WordPress Speed Optimization",
      "PSD To WordPress",
      "WordPress Support & Maintenance",
      "WordPress Customization Service",
      "WordPress Migration",
    ],
  },
];

const marketingMenu = [
  {
    title: "Digital Marketing",
    icon: Megaphone,
    items: [
      "Digital Marketing Services",
      "Digital Marketing Strategy",
      "Google Ads (Pay per Click)",
      "Quora Marketing",
      "Guest Posting",
      "Email Marketing",
      "Conversion Optimization",
      "Media Buying Services",
      "Lead generation Services",
      "Programmatic Adv. services",
      "performance marketing solution",
    ],
  },
  {
    title: "Social Media Management",
    icon: Share2,
    items: [
      "Social Media Page Management",
      "Creative Management",
      "Social Media Ads",
      "Influencer Marketing",
      "Social Media Campaigns",
      "Social Media Brand Management",
      "Instagram Marketing",
    ],
  },
  {
    title: "S.E.O",
    icon: Search,
    items: [
      "On Page Optimization",
      "Off Page Optimization",
      "SEO Content Writing",
      "Link Building",
      "SEO Audit",
      "Local SEO",
      "Online Reputition Management",
      "Page Speed Optimization Services",
    ],
  },
];

const designMenu = [
  {
    title: "UI/UX Design",
    icon: Laptop,
    items: [
      "Web UI/UX Design",
      "Mobile App UI/UX Design",
      "Wireframing & Prototyping",
      "Interface Styleguides",
    ],
  },
  {
    title: "Brand Identity",
    icon: Palette,
    items: [
      "Logo Design & Branding",
      "Typography & Color Systems",
      "Brand Book Guidelines",
      "Vector Icon Sets",
    ],
  },
  {
    title: "Digital Art & Print",
    icon: Share2,
    items: [
      "Social Media Post Designs",
      "Custom SVG Graphics",
      "Banner & Presentation Kits",
      "Packaging & Box Illustration",
    ],
  },
];

export function Header() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [devOpen, setDevOpen] = useState(false);
  const [marketingOpen, setMarketingOpen] = useState(false);
  const [designOpen, setDesignOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
  
  return (
    <header className={`sticky top-0 z-50 transition-all duration-300 ${
      scrolled 
        ? "backdrop-blur-md bg-white/90 border-b-4 border-zinc-950 shadow-sm py-1" 
        : "bg-transparent border-b-4 border-transparent py-3"
    }`}>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        
        {/* Brand Logo */}
        <Link href="/" className="flex items-center gap-2 font-display font-extrabold text-2xl text-zinc-950 select-none">
          <Rocket className="h-6 w-6 text-zinc-950 rotate-[-15deg] shrink-0 animate-pulse" />
          <span>
            Freelance
            <span className="text-white px-2.5 py-0.5 bg-zinc-950 rotate-[-2deg] ml-1.5 shadow-[2px_2px_0px_rgba(0,0,0,0.15)] text-lg inline-block">
              Seva
            </span>
          </span>
        </Link>

        {/* Desktop Links */}
        <nav className="hidden lg:flex items-center gap-1.5 lg:gap-3 xl:gap-6">
          {/* Before Links */}
          {linksBefore.map((l) => {
            const isActive = pathname === l.to;
            return (
              <Link
                key={l.to}
                href={l.to}
                className={`text-xs xl:text-sm font-semibold tracking-wide transition-all duration-200 relative py-1 whitespace-nowrap ${
                  isActive
                    ? "text-zinc-950"
                    : "text-slate-500 hover:text-zinc-950"
                }`}
              >
                {l.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 w-full h-[3px] bg-zinc-950 rounded-full" />
                )}
              </Link>
            );
          })}

          {/* Design Dropdown link (Mega Menu) */}
          <div className="relative group/design py-3">
            <button className="flex items-center gap-1 text-xs xl:text-sm font-semibold tracking-wide text-slate-500 hover:text-zinc-950 group-hover/design:text-zinc-950 transition-all duration-200 py-1 whitespace-nowrap">
              <span>Design</span>
              <ChevronDown className="w-3.5 h-3.5 transition-transform duration-200 group-hover/design:rotate-180" />
            </button>

            {/* Mega Menu Dropdown */}
            <div className="absolute top-[80%] left-1/2 -translate-x-1/2 w-[90vw] max-w-4xl bg-white border-4 border-zinc-950 rounded-3xl p-8 shadow-[8px_8px_0px_#09152e] mt-4 opacity-0 invisible group-hover/design:opacity-100 group-hover/design:visible transition-all duration-300 transform translate-y-2 group-hover/design:translate-y-0 grid grid-cols-3 gap-8 z-50 pointer-events-none group-hover/design:pointer-events-auto">
              {designMenu.map((col) => {
                const Icon = col.icon;
                return (
                  <div key={col.title} className="flex flex-col items-start">
                    {/* Column Header */}
                    <h4 className="font-doodle font-black text-lg text-zinc-950 flex items-center gap-2 mb-5 pb-2 border-b-2 border-dashed border-zinc-200 w-full text-left">
                      <span className="relative grid place-items-center w-8 h-8 border border-zinc-950 bg-amber-100 text-zinc-950 rounded-lg shadow-[1.5px_1.5px_0px_rgba(0,0,0,1)] shrink-0 select-none pointer-events-none">
                        <Icon className="w-4 h-4 z-10" />
                      </span>
                      <span>{col.title}</span>
                    </h4>
                    
                    {/* Column Items */}
                    <ul className="space-y-3 w-full text-left">
                      {col.items.map((item) => (
                        <li key={item}>
                          <Link
                            href={`/services?item=${encodeURIComponent(item)}`}
                            className="group/item flex items-center gap-2 text-slate-500 hover:text-zinc-950 transition-all font-semibold text-xs leading-relaxed"
                          >
                            <span className="text-[#10b981] font-bold select-none group-hover/item:translate-x-0.5 transition-transform">—</span>
                            <span>{item}</span>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Development Dropdown link (Mega Menu) */}
          <div className="relative group/mega py-3">
            <button className="flex items-center gap-1 text-xs xl:text-sm font-semibold tracking-wide text-slate-500 hover:text-zinc-950 group-hover/mega:text-zinc-950 transition-all duration-200 py-1 whitespace-nowrap">
              <span>Development</span>
              <ChevronDown className="w-3.5 h-3.5 transition-transform duration-200 group-hover/mega:rotate-180" />
            </button>

            {/* Mega Menu Dropdown */}
            <div className="absolute top-[80%] left-1/2 -translate-x-1/2 w-[90vw] max-w-5xl bg-white border-4 border-zinc-950 rounded-3xl p-8 shadow-[8px_8px_0px_#09152e] mt-4 opacity-0 invisible group-hover/mega:opacity-100 group-hover/mega:visible transition-all duration-300 transform translate-y-2 group-hover/mega:translate-y-0 grid grid-cols-4 gap-8 z-50 pointer-events-none group-hover/mega:pointer-events-auto">
              {developmentMenu.map((col) => {
                const Icon = col.icon;
                return (
                  <div key={col.title} className="flex flex-col items-start">
                    {/* Column Header */}
                    <h4 className="font-doodle font-black text-lg text-zinc-950 flex items-center gap-2 mb-5 pb-2 border-b-2 border-dashed border-zinc-200 w-full text-left">
                      <span className="relative grid place-items-center w-8 h-8 border border-zinc-950 bg-amber-100 text-zinc-950 rounded-lg shadow-[1.5px_1.5px_0px_rgba(0,0,0,1)] shrink-0 select-none pointer-events-none">
                        <Icon className="w-4 h-4 z-10" />
                      </span>
                      <span>{col.title}</span>
                    </h4>
                    
                    {/* Column Items */}
                    <ul className="space-y-3 w-full text-left">
                      {col.items.map((item) => (
                        <li key={item}>
                          <Link
                            href={`/services?item=${encodeURIComponent(item)}`}
                            className="group/item flex items-center gap-2 text-slate-500 hover:text-zinc-950 transition-all font-semibold text-xs leading-relaxed"
                          >
                            <span className="text-[#10b981] font-bold select-none group-hover/item:translate-x-0.5 transition-transform">—</span>
                            <span>{item}</span>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Digital Marketing Dropdown link (Mega Menu) */}
          <div className="relative group/marketing py-3">
            <button className="flex items-center gap-1 text-xs xl:text-sm font-semibold tracking-wide text-slate-500 hover:text-zinc-950 group-hover/marketing:text-zinc-950 transition-all duration-200 py-1 whitespace-nowrap">
              <span>Digital Marketing</span>
              <ChevronDown className="w-3.5 h-3.5 transition-transform duration-200 group-hover/marketing:rotate-180" />
            </button>

            {/* Mega Menu Dropdown */}
            <div className="absolute top-[80%] left-1/2 -translate-x-1/2 w-[90vw] max-w-4xl bg-white border-4 border-zinc-950 rounded-3xl p-8 shadow-[8px_8px_0px_#09152e] mt-4 opacity-0 invisible group-hover/marketing:opacity-100 group-hover/marketing:visible transition-all duration-300 transform translate-y-2 group-hover/marketing:translate-y-0 grid grid-cols-3 gap-8 z-50 pointer-events-none group-hover/marketing:pointer-events-auto">
              {marketingMenu.map((col) => {
                const Icon = col.icon;
                return (
                  <div key={col.title} className="flex flex-col items-start">
                    {/* Column Header */}
                    <h4 className="font-doodle font-black text-lg text-zinc-950 flex items-center gap-2 mb-5 pb-2 border-b-2 border-dashed border-zinc-200 w-full text-left">
                      <span className="relative grid place-items-center w-8 h-8 border border-zinc-950 bg-amber-100 text-zinc-950 rounded-lg shadow-[1.5px_1.5px_0px_rgba(0,0,0,1)] shrink-0 select-none pointer-events-none">
                        <Icon className="w-4 h-4 z-10" />
                      </span>
                      <span>{col.title}</span>
                    </h4>
                    
                    {/* Column Items */}
                    <ul className="space-y-3 w-full text-left">
                      {col.items.map((item) => (
                        <li key={item}>
                          <Link
                            href={`/services?item=${encodeURIComponent(item)}`}
                            className="group/item flex items-center gap-2 text-slate-500 hover:text-zinc-950 transition-all font-semibold text-xs leading-relaxed"
                          >
                            <span className="text-[#10b981] font-bold select-none group-hover/item:translate-x-0.5 transition-transform">—</span>
                            <span>{item}</span>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                );
              })}
            </div>
          </div>

          {/* After Links */}
          {linksAfter.map((l) => {
            const isActive = pathname === l.to;
            return (
              <Link
                key={l.to}
                href={l.to}
                className={`text-xs xl:text-sm font-semibold tracking-wide transition-all duration-200 relative py-1 whitespace-nowrap ${
                  isActive
                    ? "text-zinc-950"
                    : "text-slate-500 hover:text-zinc-950"
                }`}
              >
                {l.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 w-full h-[3px] bg-zinc-950 rounded-full" />
                )}
              </Link>
            );
          })}
        </nav>

        {/* Desktop Consultation Button */}
        <div className="hidden lg:block shrink-0">
          <Link
            href="/contact"
            className="inline-flex h-11 items-center justify-center px-4 lg:px-6 rounded-full border-2 border-zinc-950 bg-zinc-950 text-white font-sans font-extrabold text-xs lg:text-sm hover:bg-white hover:text-zinc-950 transition-all duration-300 shadow-[3px_3px_0px_#fbbf24] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 select-none whitespace-nowrap"
          >
            Book Free Consultation
          </Link>
        </div>

        {/* Mobile Toggle Button */}
        <button
          aria-label="Toggle menu"
          className="lg:hidden p-2.5 border-2 border-zinc-950 bg-white text-zinc-950 rounded-xl shadow-[2px_2px_0px_#09152e] active:shadow-none active:translate-x-0.5 active:translate-y-0.5 transition-all"
          onClick={() => setOpen(!open)}
        >
          {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>

      </div>

      {/* Mobile Drawer */}
      {open && (
        <div className="lg:hidden border-t-2 border-zinc-950 bg-white">
          <div className="px-4 py-6 flex flex-col gap-4 max-h-[80vh] overflow-y-auto">
            {/* Before Links */}
            {linksBefore.map((l) => {
              const isActive = pathname === l.to;
              return (
                <Link
                  key={l.to}
                  href={l.to}
                  onClick={() => setOpen(false)}
                  className={`py-2 text-base font-bold transition-all ${
                    isActive 
                      ? "text-zinc-950 underline decoration-zinc-950 decoration-2 underline-offset-4" 
                      : "text-slate-500 hover:text-zinc-950"
                  }`}
                >
                  {l.label}
                </Link>
              );
            })}

            {/* Design dropdown item for Mobile */}
            <div className="flex flex-col gap-2">
              <button 
                onClick={() => setDesignOpen(!designOpen)}
                className="flex items-center justify-between py-2 text-base font-bold text-slate-500 hover:text-zinc-950 transition-colors w-full text-left"
              >
                <span>Design</span>
                <ChevronDown className={`w-5 h-5 transition-transform duration-200 ${designOpen ? "rotate-180 text-zinc-950" : ""}`} />
              </button>
              
              {designOpen && (
                <div className="pl-4 border-l-2 border-zinc-950 flex flex-col gap-5 mt-2">
                  {designMenu.map((col) => {
                    const Icon = col.icon;
                    return (
                      <div key={col.title} className="flex flex-col items-start gap-2">
                        <h5 className="font-doodle font-black text-sm text-zinc-950 flex items-center gap-1.5 uppercase tracking-wide">
                          <Icon className="w-4 h-4 text-zinc-950" /> {col.title}
                        </h5>
                        <ul className="pl-4 border-l border-zinc-200 flex flex-col gap-2 w-full text-left">
                          {col.items.map((item) => (
                            <li key={item}>
                              <Link
                                href={`/services?item=${encodeURIComponent(item)}`}
                                onClick={() => setOpen(false)}
                                className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-zinc-950 transition-colors"
                              >
                                <span className="text-[#10b981] font-bold">—</span>
                                <span>{item}</span>
                              </Link>
                            </li>
                          ))}
                        </ul>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Development dropdown item for Mobile */}
            <div className="flex flex-col gap-2">
              <button 
                onClick={() => setDevOpen(!devOpen)}
                className="flex items-center justify-between py-2 text-base font-bold text-slate-500 hover:text-zinc-950 transition-colors w-full text-left"
              >
                <span>Development</span>
                <ChevronDown className={`w-5 h-5 transition-transform duration-200 ${devOpen ? "rotate-180 text-zinc-950" : ""}`} />
              </button>
              
              {devOpen && (
                <div className="pl-4 border-l-2 border-zinc-950 flex flex-col gap-5 mt-2">
                  {developmentMenu.map((col) => {
                    const Icon = col.icon;
                    return (
                      <div key={col.title} className="flex flex-col items-start gap-2">
                        <h5 className="font-doodle font-black text-sm text-zinc-950 flex items-center gap-1.5 uppercase tracking-wide">
                          <Icon className="w-4 h-4 text-zinc-950" /> {col.title}
                        </h5>
                        <ul className="pl-4 border-l border-zinc-200 flex flex-col gap-2 w-full text-left">
                          {col.items.map((item) => (
                            <li key={item}>
                              <Link
                                href={`/services?item=${encodeURIComponent(item)}`}
                                onClick={() => setOpen(false)}
                                className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-zinc-950 transition-colors"
                              >
                                <span className="text-[#10b981] font-bold">—</span>
                                <span>{item}</span>
                              </Link>
                            </li>
                          ))}
                        </ul>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Digital Marketing dropdown item for Mobile */}
            <div className="flex flex-col gap-2">
              <button 
                onClick={() => setMarketingOpen(!marketingOpen)}
                className="flex items-center justify-between py-2 text-base font-bold text-slate-500 hover:text-zinc-950 transition-colors w-full text-left"
              >
                <span>Digital Marketing</span>
                <ChevronDown className={`w-5 h-5 transition-transform duration-200 ${marketingOpen ? "rotate-180 text-zinc-950" : ""}`} />
              </button>
              
              {marketingOpen && (
                <div className="pl-4 border-l-2 border-zinc-950 flex flex-col gap-5 mt-2">
                  {marketingMenu.map((col) => {
                    const Icon = col.icon;
                    return (
                      <div key={col.title} className="flex flex-col items-start gap-2">
                        <h5 className="font-doodle font-black text-sm text-zinc-950 flex items-center gap-1.5 uppercase tracking-wide">
                          <Icon className="w-4 h-4 text-zinc-950" /> {col.title}
                        </h5>
                        <ul className="pl-4 border-l border-zinc-200 flex flex-col gap-2 w-full text-left">
                          {col.items.map((item) => (
                            <li key={item}>
                              <Link
                                href={`/services?item=${encodeURIComponent(item)}`}
                                onClick={() => setOpen(false)}
                                className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-zinc-950 transition-colors"
                              >
                                <span className="text-[#10b981] font-bold">—</span>
                                <span>{item}</span>
                              </Link>
                            </li>
                          ))}
                        </ul>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* After Links */}
            {linksAfter.map((l) => {
              const isActive = pathname === l.to;
              return (
                <Link
                  key={l.to}
                  href={l.to}
                  onClick={() => setOpen(false)}
                  className={`py-2 text-base font-bold transition-all ${
                    isActive 
                      ? "text-zinc-950 underline decoration-zinc-950 decoration-2 underline-offset-4" 
                      : "text-slate-500 hover:text-zinc-950"
                  }`}
                >
                  {l.label}
                </Link>
              );
            })}
            
            <Link
              href="/contact"
              onClick={() => setOpen(false)}
              className="mt-3 inline-flex h-12 items-center justify-center rounded-full border-2 border-zinc-950 bg-zinc-950 text-white font-sans font-extrabold text-base shadow-[3px_3px_0px_#fbbf24] hover:bg-white hover:text-zinc-950 transition-colors"
            >
              Book Free Consultation
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
