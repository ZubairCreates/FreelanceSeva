"use client";

import { motion, useScroll, useSpring } from "framer-motion";

export function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  
  // Create a spring physics wrapper for smooth tracking
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 120,
    damping: 25,
    restDelta: 0.001,
  });

  return (
    <motion.div
      className="fixed top-0 left-0 right-0 h-1.5 bg-amber-400 border-b-2 border-zinc-950 origin-left z-[9999] pointer-events-none"
      style={{ scaleX }}
    />
  );
}
