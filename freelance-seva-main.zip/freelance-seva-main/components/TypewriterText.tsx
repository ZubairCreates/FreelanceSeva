"use client";

import Typewriter from 'typewriter-effect';

export function TypewriterText() {
  return (
    <span className="text-[#0f67f6] inline-block">
      <Typewriter
        options={{
          strings: ['Online Presence', 'Digital Growth', 'Brand Identity', 'Market Reach'],
          autoStart: true,
          loop: true,
          delay: 80,
          deleteSpeed: 50,
          cursor: "|",
        }}
      />
    </span>
  );
}
