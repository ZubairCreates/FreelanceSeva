"use client";

import { Mail, MapPin, Phone, Send, Loader2 } from "lucide-react";
import { useState } from "react";

export default function Contact() {
  const [submitting, setSubmitting] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);

    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData.entries());

    const formspreeId = process.env.NEXT_PUBLIC_FORMSPREE_FORM_ID;
    let endpoint = "https://formspree.io/info@freelanceseva.com";

    if (formspreeId) {
      const trimmed = formspreeId.trim();
      if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
        endpoint = trimmed;
      } else if (trimmed.includes("@")) {
        endpoint = `https://formspree.io/${trimmed}`;
      } else {
        endpoint = `https://formspree.io/f/${trimmed}`;
      }
    }

    try {
      const response = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify(data)
      });

      if (response.ok) {
        setSent(true);
      } else {
        const resData = await response.json();
        setError(resData.errors?.[0]?.message || resData.error || "Something went wrong. Please try again.");
      }
    } catch (err) {
      setError("Failed to send message. Please check your internet connection.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      {/* Header section with sketchy theme */}
      <section className="bg-white border-b-4 border-zinc-950 py-24 relative overflow-hidden">
        {/* Grid paper mesh blueprint background */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#00000003_1px,transparent_1px),linear-gradient(to_bottom,#00000003_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none z-0" />
        <div className="relative mx-auto max-w-3xl px-4 text-center z-10">
          <div className="relative inline-flex items-center justify-center px-6 py-2 select-none font-doodle text-lg font-bold text-white tracking-wider uppercase animate-wiggle shrink-0 mb-4">
            <svg className="absolute inset-0 w-full h-full text-zinc-950 fill-current" viewBox="0 0 140 50" preserveAspectRatio="none">
              <path d="M5,5 C40,2 100,2 135,5 C138,15 138,35 135,45 C100,48 40,48 5,45 C2,35 2,15 5,5 Z" />
              <path d="M65,44 L70,51 L75,44 Z" />
            </svg>
            <span className="relative z-10 pt-0.5">Contact</span>
          </div>

          <h1 className="mt-4 font-doodle text-4xl sm:text-6xl font-extrabold text-zinc-900 leading-tight">
            Let's talk <span className="inline-block text-white mt-1 pb-1 sm:pb-2" style={{ WebkitTextStroke: '1.5px #09152e', textShadow: '2.5px 2.5px 0px #09152e' }}>growth.</span>
          </h1>
          <p className="mt-6 text-slate-600 font-semibold text-lg sm:text-xl">Tell us about your business — we'll respond within 24 hours.</p>
        </div>
      </section>

      {/* Main Form content */}
      <section className="py-24 bg-white relative">
        <div className="mx-auto max-w-6xl px-4 grid gap-12 lg:grid-cols-5">

          {/* Left Column info cards */}
          <div className="lg:col-span-2 space-y-6">
            {[
              { Icon: MapPin, t: "Office", v: "Zakir Nagar, Okhla, New Delhi-110025" },
              {
                Icon: Mail, t: "Email", v: (
                  <a href="mailto:info@freelanceseva.com" className="hover:underline text-zinc-950 font-bold">
                    info@freelanceseva.com
                  </a>
                )
              },
              {
                Icon: Phone, t: "Phone", v: (
                  <span className="block space-y-1">
                    <a href="tel:+916397801840" className="hover:underline block text-zinc-950 font-bold">+91 6397801840</a>
                    <a href="tel:+919027166138" className="hover:underline block text-zinc-950 font-bold">+91 9027166138</a>
                    <a href="tel:+918077128072" className="hover:underline block text-zinc-950 font-bold">+91 8077128072</a>
                  </span>
                )
              },
            ].map(({ Icon, t, v }) => (
              <div key={t} className="group relative flex items-start gap-4 p-6 bg-white border-2 border-zinc-950 rounded-2xl shadow-[4px_4px_0px_#09152e] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 transition-all duration-300">
                <span className="relative grid place-items-center w-12 h-12 text-zinc-950 font-bold shrink-0 select-none pointer-events-none group-hover:rotate-6 transition-transform duration-300">
                  <svg className="absolute inset-0 w-full h-full text-zinc-950 fill-none" viewBox="0 0 50 50">
                    <path d="M25,5 C14,5 5,14 5,25 C5,36 14,45 25,45 C36,45 45,36 45,25 C45,14 36,5 25,5 C18,4 10,8 25,5" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                  </svg>
                  <Icon className="w-5 h-5 z-10" />
                </span>
                <div>
                  <h3 className="font-doodle font-black text-xl text-zinc-950 leading-tight">{t}</h3>
                  <div className="text-sm text-slate-600 font-semibold mt-2 leading-relaxed">{v}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Right Column Form */}
          <form
            onSubmit={handleSubmit}
            className="lg:col-span-3 relative overflow-hidden rounded-3xl border-2 border-zinc-950 bg-white p-8 sm:p-10 shadow-[6px_6px_0px_#09152e] space-y-6"
          >
            {/* Grid paper mesh inside card */}
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#00000002_1px,transparent_1px),linear-gradient(to_bottom,#00000002_1px,transparent_1px)] bg-[size:16px_16px] pointer-events-none z-0" />

            {sent ? (
              <div className="text-center py-16 relative z-10 flex flex-col items-center">
                <h3 className="font-doodle font-black text-3xl sm:text-4xl text-zinc-950">Thank you! 🎉</h3>
                <p className="mt-4 text-slate-600 font-semibold text-base sm:text-lg">We've received your message and will reply within 24 hours.</p>
              </div>
            ) : (
              <div className="space-y-6 relative z-10">
                {error && (
                  <div className="p-4 border-2 border-zinc-950 bg-rose-50 text-rose-950 rounded-xl font-semibold text-sm shadow-[2px_2px_0px_rgba(0,0,0,0.1)]">
                    {error}
                  </div>
                )}
                
                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <label className="text-sm font-black text-zinc-950 font-doodle uppercase tracking-wider" htmlFor="name">Your name</label>
                    <input id="name" name="name" required className="mt-2 w-full h-12 rounded-xl border-2 border-zinc-950 bg-white px-4 text-sm font-semibold focus:outline-none focus:border-zinc-900 transition-colors" />
                  </div>
                  <div>
                    <label className="text-sm font-black text-zinc-950 font-doodle uppercase tracking-wider" htmlFor="email">Email</label>
                    <input id="email" name="email" type="email" required className="mt-2 w-full h-12 rounded-xl border-2 border-zinc-950 bg-white px-4 text-sm font-semibold focus:outline-none focus:border-zinc-900 transition-colors" />
                  </div>
                </div>
                <div>
                  <label className="text-sm font-black text-zinc-950 font-doodle uppercase tracking-wider" htmlFor="company">Company / Brand</label>
                  <input id="company" name="company" className="mt-2 w-full h-12 rounded-xl border-2 border-zinc-950 bg-white px-4 text-sm font-semibold focus:outline-none focus:border-zinc-900 transition-colors" />
                </div>
                <div>
                  <label className="text-sm font-black text-zinc-950 font-doodle uppercase tracking-wider" htmlFor="msg">How can we help?</label>
                  <textarea id="msg" name="message" rows={5} required className="mt-2 w-full rounded-xl border-2 border-zinc-950 bg-white px-4 py-3 text-sm font-semibold focus:outline-none focus:border-zinc-900 transition-colors" />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={submitting}
                    className="inline-flex h-14 items-center justify-center px-10 rounded-full border-2 border-zinc-950 bg-zinc-950 text-white font-doodle font-black text-lg hover:bg-white hover:text-zinc-950 transition-all duration-300 shadow-[4px_4px_0px_#fbbf24] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 select-none w-full sm:w-auto disabled:opacity-75 disabled:cursor-not-allowed"
                  >
                    {submitting ? (
                      <>
                        Sending... <Loader2 className="w-5 h-5 ml-2 animate-spin" />
                      </>
                    ) : (
                      <>
                        Send message <Send className="w-5 h-5 ml-2" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </form>

        </div>
      </section>
    </>
  );
}
