import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Calendar, User, Share2 } from "lucide-react";
import { blogs } from "@/data/blogs";

interface Props {
  params: { slug: string };
}

export async function generateStaticParams() {
  return blogs.map((post) => ({
    slug: post.slug,
  }));
}

export default function BlogPost({ params }: Props) {
  const post = blogs.find((b) => b.slug === params.slug);

  if (!post) {
    notFound();
  }

  return (
    <article className="pb-24 bg-white relative">
      {/* HEADER */}
      <header className="relative pt-24 pb-16 overflow-hidden border-b-4 border-zinc-950">
        {/* Grid paper mesh blueprint background */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#00000003_1px,transparent_1px),linear-gradient(to_bottom,#00000003_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none z-0" />
        
        <div className="relative mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 z-10">
          <Link 
            href="/blog" 
            className="inline-flex items-center gap-2 text-base font-bold text-slate-500 hover:text-zinc-950 transition-colors mb-8"
          >
            <ArrowLeft className="w-4.5 h-4.5" /> Back to all posts
          </Link>
          <div className="flex flex-col gap-4">
            <span className="inline-flex w-fit items-center rounded-full border-2 border-zinc-950 bg-zinc-950 text-white font-doodle text-[10px] font-black uppercase tracking-wider px-3.5 py-1.5 shadow-[2px_2px_0px_#fbbf24] select-none pointer-events-none">
              {post.category}
            </span>
            <h1 className="font-doodle font-black text-3xl sm:text-5xl lg:text-6xl text-zinc-950 leading-tight mt-2">
              {post.title}
            </h1>
            <div className="flex items-center gap-6 text-sm font-bold text-slate-500 mt-4 select-none pointer-events-none">
              <span className="flex items-center gap-1.5"><Calendar className="w-4 h-4 shrink-0" /> {post.date}</span>
              <span className="flex items-center gap-1.5"><User className="w-4 h-4 shrink-0" /> {post.author}</span>
            </div>
          </div>
        </div>
      </header>

      {/* FEATURED IMAGE */}
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 -mt-12 relative z-10">
        <div className="relative aspect-[1200/628] rounded-3xl overflow-hidden border-2 border-zinc-950 shadow-[6px_6px_0px_#09152e] select-none pointer-events-none">
          <Image 
            src={post.image} 
            alt={post.title} 
            fill 
            sizes="(max-width: 1024px) 100vw, 1024px"
            className="object-cover"
            priority
          />
        </div>
      </div>

      {/* CONTENT */}
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 mt-16 relative">
        <div 
          className="prose prose-lg max-w-none text-slate-600 font-semibold
          prose-headings:text-zinc-950 prose-headings:font-black prose-headings:font-doodle
          prose-h2:text-3xl prose-h2:mt-12 prose-h2:mb-6
          prose-p:mb-6 prose-p:leading-relaxed
          prose-strong:text-zinc-950
          prose-ul:list-disc prose-ul:pl-6 prose-ul:mb-6
          prose-li:mb-2"
          dangerouslySetInnerHTML={{ __html: post.content }}
        />

        {/* FOOTER / SHARE */}
        <footer className="mt-16 pt-8 border-t-2 border-zinc-950 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="text-sm font-black text-zinc-950 font-doodle uppercase tracking-wider">Tags:</span>
            <span className="text-xs font-bold text-zinc-950 bg-amber-50 border-2 border-zinc-950 px-3.5 py-1 rounded-full shadow-[1.5px_1.5px_0px_#09152e] select-none pointer-events-none">{post.seoKeyword}</span>
          </div>
          <div className="flex items-center gap-3">
             <span className="text-sm font-bold text-slate-500 select-none">Share:</span>
             <button className="p-2 border-2 border-zinc-950 bg-white text-zinc-950 rounded-full shadow-[2px_2px_0px_#09152e] active:shadow-none active:translate-x-0.5 active:translate-y-0.5 transition-all"><Share2 className="w-4.5 h-4.5" /></button>
          </div>
        </footer>
      </div>

      {/* RELATED POSTS / CTA */}
      <section className="mt-24 py-24 border-y-4 border-zinc-950 bg-white relative overflow-hidden">
        {/* Dotted mesh grid */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#00000003_1px,transparent_1px),linear-gradient(to_bottom,#00000003_1px,transparent_1px)] bg-[size:18px_18px] pointer-events-none z-0" />
        
        <div className="mx-auto max-w-4xl px-4 text-center relative z-10">
          <h2 className="font-doodle text-4xl sm:text-5xl font-extrabold text-zinc-950">Ready to grow your business?</h2>
          <p className="mt-6 text-slate-600 font-semibold text-lg max-w-xl mx-auto">
            Let's apply these strategies to your brand. Book a free consultation and get a personalized growth audit.
          </p>
          
          <div className="mt-10">
            <Link href="/contact" className="inline-flex h-14 items-center justify-center px-10 rounded-full border-2 border-zinc-950 bg-zinc-950 text-white font-doodle font-black text-lg hover:bg-white hover:text-zinc-950 transition-all duration-300 shadow-[4px_4px_0px_#fbbf24] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 select-none">
              Book Free Consultation
            </Link>
          </div>
        </div>
      </section>
    </article>
  );
}
