import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Calendar, User } from "lucide-react";
import { blogs } from "@/data/blogs";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Blog — Digital Marketing Insights | FreelanceSeva",
  description: "Read the latest insights on web design, SEO, and digital marketing strategies to grow your business in India.",
};

export default function BlogListing() {
  return (
    <>
      {/* HERO  */}
      <section className="bg-white border-b-4 border-zinc-950 py-24 relative overflow-hidden">
        {/* Grid paper mesh blueprint background */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#00000003_1px,transparent_1px),linear-gradient(to_bottom,#00000003_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none z-0" />

        <div className="relative mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center z-10">
          <div className="relative inline-flex items-center justify-center px-6 py-2 select-none font-doodle text-lg font-bold text-white tracking-wider uppercase animate-wiggle shrink-0 mb-4">
            <svg className="absolute inset-0 w-full h-full text-zinc-950 fill-current" viewBox="0 0 140 50" preserveAspectRatio="none">
              <path d="M5,5 C40,2 100,2 135,5 C138,15 138,35 135,45 C100,48 40,48 5,45 C2,35 2,15 5,5 Z" />
              <path d="M65,44 L70,51 L75,44 Z" />
            </svg>
            <span className="relative z-10 pt-0.5">Insights & Resources</span>
          </div>

          <h1 className="mt-4 font-doodle text-4xl sm:text-6xl font-extrabold text-zinc-900 leading-tight">
            The FreelanceSeva <span className="inline-block text-white mt-1 pb-1 sm:pb-2" style={{ WebkitTextStroke: '1.5px #09152e', textShadow: '2.5px 2.5px 0px #09152e' }}>Blog</span>
          </h1>
          <p className="mt-6 text-slate-600 font-semibold text-lg sm:text-xl max-w-2xl mx-auto">
            Practical strategies and deep dives into web design, e-commerce, and digital marketing tailored for the Indian market.
          </p>
        </div>
      </section>

      {/* BLOG GRID */}
      <section className="py-24 bg-white relative">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-3">
            {blogs.map((post) => (
              <Link
                key={post.slug}
                href={`/blog/${post.slug}`}
                className="group flex flex-col rounded-3xl border-2 border-zinc-950 bg-white overflow-hidden shadow-[4px_4px_0px_#09152e] hover:shadow-[6px_6px_0px_#09152e] hover:-translate-x-0.5 hover:-translate-y-0.5 transition-all duration-300 min-h-[380px]"
              >
                {/* Image Wrap */}
                <div className="relative aspect-[1200/628] overflow-hidden border-b-2 border-zinc-950 select-none pointer-events-none">
                  <Image
                    src={post.image}
                    alt={post.title}
                    fill
                    sizes="(max-width: 768px) 100vw, (max-width: 1024px) 50vw, 33vw"
                    className="object-cover group-hover:scale-[1.03] transition-transform duration-500"
                  />

                  {/* Category Badge */}
                  <div className="absolute top-4 left-4 z-10">
                    <span className="inline-flex items-center rounded-full border-2 border-zinc-950 bg-zinc-950 text-white font-doodle text-[10px] font-black uppercase tracking-wider px-3 py-1 shadow-[2px_2px_0px_#fbbf24]">
                      {post.category}
                    </span>
                  </div>
                </div>

                {/* Info Block */}
                <div className="p-6 flex flex-col flex-grow">
                  <div className="flex items-center gap-4 text-xs font-bold text-slate-500 mb-4 select-none pointer-events-none">
                    <span className="flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5 shrink-0" /> {post.date}</span>
                    <span className="flex items-center gap-1.5"><User className="w-3.5 h-3.5 shrink-0" /> {post.author}</span>
                  </div>

                  <h2 className="font-doodle font-black text-xl text-zinc-950 leading-tight mb-3">
                    {post.title}
                  </h2>

                  <p className="text-sm text-slate-600 font-semibold line-clamp-3 mb-6">
                    {post.excerpt}
                  </p>

                  <div className="mt-auto flex items-center gap-2 text-sm font-black text-zinc-950">
                    Read Article <ArrowRight className="w-4 h-4" />
                  </div>
                </div>

              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* NEWSLETTER / CTA */}
      <section className="py-24 border-y-4 border-zinc-950 bg-white relative overflow-hidden">
        {/* Dotted mesh grid */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#00000003_1px,transparent_1px),linear-gradient(to_bottom,#00000003_1px,transparent_1px)] bg-[size:18px_18px] pointer-events-none z-0" />

        <div className="mx-auto max-w-3xl px-4 text-center relative z-10">
          <h2 className="font-doodle text-4xl sm:text-5xl font-extrabold text-zinc-950 leading-tight">Stay ahead of the curve</h2>
          <p className="mt-6 text-slate-600 font-semibold text-lg max-w-xl mx-auto">Get our latest digital marketing insights delivered straight to your inbox.</p>

          <div className="mt-10 flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
            <input
              type="email"
              placeholder="Your email address"
              className="h-14 flex-grow rounded-full border-2 border-zinc-950 bg-white px-6 text-sm font-semibold focus:outline-none focus:border-zinc-900 transition-colors"
            />
            <button className="h-14 inline-flex items-center justify-center px-8 rounded-full border-2 border-zinc-950 bg-zinc-950 text-white font-doodle font-black text-lg hover:bg-white hover:text-zinc-950 transition-all duration-300 shadow-[4px_4px_0px_#fbbf24] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 select-none shrink-0 w-full sm:w-auto">
              Subscribe
            </button>
          </div>
        </div>
      </section>
    </>
  );
}
