import Link from "next/link";
import Image from "next/image";
import { Check, Rocket } from "lucide-react";
import teamImg from "@/assets/team.jpg";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "About — FreelanceSeva Agency",
  description: "Meet the team behind FreelanceSeva: an AI-first digital marketing agency on a mission to make growth fast, smart and affordable.",
};

const team = [
  {
    name: "Farhan",
    role: "Co-Founder & Strategy Lead",
    desc: "Farhan is a strategic thinker and co-founder who plays a key role in managing business growth and operations. From building strong client relationships and handling business pitching to integrating AI tools and ensuring quality assurance, he focuses on creating smart and effective solutions. With a practical mindset and strong leadership skills, Farhan helps drive the team forward through planning, innovation, and smooth business operations.",
    highlight: true
  },
  {
    name: "Zeeshan",
    role: "Co-Founder & Business Lead",
    desc: "Zeeshan is the driving force behind FreelanceSeva's client relationships and business strategy. With a strong academic background and years of experience in both the technology sectors, he brings a rare combination of analytical thinking and people-first leadership to every project. Zeeshan oversees client onboarding, project scoping, and business development.",
  },
  {
    name: "Zubair",
    role: "Co-Founder & Creative Lead",
    desc: "Zubair is a creative professional and co-founder who helps brands grow through digital solutions. With experience in website design & development, social media content creation, and video reels editing, he focuses on creating engaging and impactful content that connects with people. He believes in turning ideas into visually appealing and professional results.",
  },
];

export default function About() {
  return (
    <>
      {/* COMPANY STORY */}
      <section className="py-24 overflow-hidden bg-white relative">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-16 lg:grid-cols-2 items-center">

            {/* Story Image Card */}
            <div className="relative flex justify-center z-10 animate-float">
              <div className="absolute inset-0 bg-[linear-gradient(to_right,#00000002_1px,transparent_1px),linear-gradient(to_bottom,#00000002_1px,transparent_1px)] bg-[size:16px_16px] pointer-events-none rounded-2xl" />
              <Image
                src={teamImg}
                alt="FreelanceSeva team"
                width={1024}
                height={768}
                className="relative rounded-2xl border-4 border-zinc-950 shadow-[6px_6px_0px_#09152e] w-full h-auto select-none pointer-events-none"
                priority
              />
            </div>

            {/* Story Text Column */}
            <div className="relative z-10 flex flex-col items-start">
              {/* Speech Bubble Badge */}
              <div className="relative inline-flex items-center justify-center px-6 py-2 select-none font-doodle text-lg font-bold text-white tracking-wider uppercase animate-wiggle shrink-0 mb-4">
                <svg className="absolute inset-0 w-full h-full text-zinc-950 fill-current" viewBox="0 0 140 50" preserveAspectRatio="none">
                  <path d="M5,5 C40,2 100,2 135,5 C138,15 138,35 135,45 C100,48 40,48 5,45 C2,35 2,15 5,5 Z" />
                  <path d="M65,44 L70,51 L75,44 Z" />
                </svg>
                <span className="relative z-10 pt-0.5">Our Story</span>
              </div>

              <h1 className="mt-4 font-doodle text-4xl sm:text-5xl font-extrabold text-zinc-900 leading-tight">
                Making digital growth <span className="inline-block text-white mt-1 pb-1 sm:pb-2" style={{ WebkitTextStroke: '1.5px #09152e', textShadow: '2.5px 2.5px 0px #09152e' }}>accessible.</span>
              </h1>

              <div className="mt-8 space-y-5 text-slate-600 font-semibold text-base sm:text-lg leading-relaxed">
                <p>
                  FreelanceSeva was founded with one clear purpose: to make professional digital services genuinely accessible to Indian businesses — whether you run a local shop, a growing startup, or an established enterprise.
                </p>
                <p>
                  We started as a small team of web designers and marketers who noticed a significant gap in the market. Many small and mid-sized businesses were either paying far too much for mediocre results or struggling to find reliable, transparent digital partners. We set out to change that.
                </p>
                <p>
                  Over the years, we have grown into a full-service digital agency with expertise spanning website design, e-commerce development, SEO, social media marketing, and paid advertising. Our team brings together creative designers, technical developers, and performance marketers who collaborate closely on every project.
                </p>
                <p>
                  What sets us apart is our commitment to clarity — clear communication, clear deliverables, and clear results. We do not believe in complicated jargon or vague promises. We believe in building long-term relationships through consistent, measurable work that actually moves your business forward.
                </p>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* MISSION & VISION */}
      <section className="py-24 border-y-4 border-zinc-950 bg-white relative overflow-hidden">
        {/* Dotted Grid Paper mesh */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#00000003_1px,transparent_1px),linear-gradient(to_bottom,#00000003_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none z-0" />

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid gap-12 md:grid-cols-2 z-10">

          {/* Mission Card */}
          <div className="group rounded-2xl bg-white border-2 border-zinc-950 p-10 shadow-[6px_6px_0px_#09152e] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 transition-all duration-300 flex flex-col items-start">
            <span className="relative grid place-items-center w-14 h-14 text-zinc-950 font-bold mb-6 select-none pointer-events-none group-hover:rotate-6 transition-transform duration-300">
              <svg className="absolute inset-0 w-full h-full text-zinc-950 fill-none" viewBox="0 0 50 50">
                <path d="M25,5 C14,5 5,14 5,25 C5,36 14,45 25,45 C36,45 45,36 45,25 C45,14 36,5 25,5 C18,4 10,8 25,5" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
              </svg>
              <Check className="w-7 h-7 z-10" />
            </span>
            <h2 className="font-doodle font-black text-2xl text-zinc-950 mb-4">Our Mission</h2>
            <p className="text-slate-600 font-semibold text-sm/relaxed leading-relaxed italic">
              "To empower Indian businesses with professional, results-driven digital solutions — delivered transparently, affordably, and with genuine dedication. We are committed to building online presences that not only look impressive but consistently generate enquiries, sales, and long-term growth for every client we work with."
            </p>
          </div>

          {/* Vision Card */}
          <div className="group rounded-2xl bg-white border-2 border-zinc-950 p-10 shadow-[6px_6px_0px_#09152e] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 transition-all duration-300 flex flex-col items-start">
            <span className="relative grid place-items-center w-14 h-14 text-zinc-950 font-bold mb-6 select-none pointer-events-none group-hover:rotate-6 transition-transform duration-300">
              <svg className="absolute inset-0 w-full h-full text-zinc-950 fill-none" viewBox="0 0 50 50">
                <path d="M25,5 C14,5 5,14 5,25 C5,36 14,45 25,45 C36,45 45,36 45,25 C45,14 36,5 25,5 C18,4 10,8 25,5" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
              </svg>
              <Rocket className="w-7 h-7 z-10" />
            </span>
            <h2 className="font-doodle font-black text-2xl text-zinc-950 mb-4">Our Vision</h2>
            <p className="text-slate-600 font-semibold text-sm/relaxed leading-relaxed italic">
              "To become India's most trusted digital partner for small and mid-sized businesses — a company known not just for the quality of its work, but for the integrity of its relationships, the transparency of its process, and the measurable impact it delivers across every engagement."
            </p>
          </div>

        </div>
      </section>

      {/* TEAM */}
      <section className="py-24 bg-white relative">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">

          <div className="text-center max-w-2xl mx-auto mb-20">
            {/* Badge */}
            <div className="relative inline-flex items-center justify-center px-6 py-2 select-none font-doodle text-lg font-bold text-white tracking-wider uppercase animate-wiggle shrink-0 mb-4">
              <svg className="absolute inset-0 w-full h-full text-zinc-950 fill-current" viewBox="0 0 140 50" preserveAspectRatio="none">
                <path d="M5,5 C40,2 100,2 135,5 C138,15 138,35 135,45 C100,48 40,48 5,45 C2,35 2,15 5,5 Z" />
                <path d="M65,44 L70,51 L75,44 Z" />
              </svg>
              <span className="relative z-10 pt-0.5">The Team</span>
            </div>

            <h2 className="mt-4 font-doodle text-4xl sm:text-5xl font-extrabold text-zinc-900 leading-tight">
              Meet the <span className="inline-block text-white mt-1 pb-1 sm:pb-2" style={{ WebkitTextStroke: '1.5px #09152e', textShadow: '2.5px 2.5px 0px #09152e' }}>founders</span>
            </h2>
            <p className="mt-6 text-slate-600 text-lg font-medium">The dedicated team behind your digital success.</p>
          </div>

          <div className="grid gap-8 grid-cols-1 lg:grid-cols-3 max-w-xl mx-auto lg:max-w-none">
            {team.map((m) => (
              <div
                key={m.name}
                className="group relative rounded-2xl border-2 border-zinc-950 bg-white p-8 shadow-[4px_4px_0px_#09152e] hover:shadow-[6px_6px_0px_#09152e] hover:-translate-x-0.5 hover:-translate-y-0.5 transition-all duration-300 relative flex flex-col items-center justify-start min-h-[360px]"
              >
                {m.highlight && (
                  <span className="absolute -top-4.5 left-1/2 -translate-x-1/2 rounded-full border-2 border-zinc-950 bg-zinc-950 text-white font-doodle text-xs font-black uppercase tracking-wider px-5 py-1.5 shadow-[2px_2px_0px_#fbbf24]">
                    Strategy Lead
                  </span>
                )}

                {/* Initial Badge Circle */}
                <div className="relative w-16 h-16 rounded-full border-2 border-zinc-950 bg-zinc-950 text-white grid place-items-center font-doodle text-2xl font-black mb-6 mx-auto shadow-[3px_3px_0px_#fbbf24] group-hover:rotate-6 transition-transform duration-300 select-none pointer-events-none">
                  {m.name[0]}
                </div>

                <div className="text-center flex flex-col items-center">
                  <h3 className="font-doodle font-black text-2xl text-zinc-950">{m.name}</h3>
                  <p className="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1 mb-6 leading-none">{m.role}</p>
                  <p className="text-sm text-slate-600 font-semibold leading-relaxed">
                    {m.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>
    </>
  );
}
