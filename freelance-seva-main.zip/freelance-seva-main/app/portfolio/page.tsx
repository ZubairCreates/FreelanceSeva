import Image from "next/image";
import Link from "next/link";
import { ArrowRight, ExternalLink } from "lucide-react";
import type { Metadata } from "next";

// Import images
import freshbasket from "@/assets/portfolio/freshbasket_portfolio_1778962370690.png";
import legaledge from "@/assets/portfolio/legaledge_portfolio_1778962386314.png";
import fitzone from "@/assets/portfolio/fitzone_portfolio_1778962402270.png";
import threadcraft from "@/assets/portfolio/threadcraft_portfolio_1778962416381.png";
import swiftcargo from "@/assets/portfolio/swiftcargo_portfolio_1778962431174.png";

export const metadata: Metadata = {
  title: "Portfolio — FreelanceSeva Agency",
  description: "Explore our latest projects in web design, e-commerce, and digital marketing. Real results for real businesses.",
};

const projects = [
  {
    title: "FreshBasket Grocery Store",
    category: "E-Commerce",
    status: "Completed",
    desc: "A full-featured Shopify store for an organic grocery brand. Included product filtering, subscription boxes, and integrated delivery tracking for a seamless customer experience.",
    image: freshbasket,
  },
  {
    title: "LegalEdge Advocates",
    category: "Website Design",
    status: "Completed",
    desc: "A professional multi-page website for a law firm in Delhi. Designed for credibility and trust with structured service pages, team profiles, and an integrated client enquiry form.",
    image: legaledge,
  },
  {
    title: "FitZone Gym",
    category: "SEO + Social Media",
    status: "Completed",
    desc: "A 6-month SEO and social media campaign that increased organic traffic by 180% and doubled Instagram followers for a fitness centre in Noida.",
    image: fitzone,
  },
  {
    title: "ThreadCraft Fashion",
    category: "E-Commerce + Branding",
    status: "Completed",
    desc: "End-to-end brand identity and WooCommerce store for an ethnic wear label. Included logo design, lookbook pages, and size guide integration for improved user experience.",
    image: threadcraft,
  },
  {
    title: "SwiftCargo Logistics",
    category: "Website + Google Ads",
    status: "Completed",
    desc: "A lead-generation website paired with a Google Ads campaign for a logistics company. Achieved a 40% reduction in cost-per-lead within the first two months of the campaign.",
    image: swiftcargo,
  },
];

export default function Portfolio() {
  return (
    <>
      {/* HERO */}
      <section className="bg-white border-b-4 border-zinc-950 py-24 relative overflow-hidden">
        {/* Grid paper mesh blueprint background */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#00000003_1px,transparent_1px),linear-gradient(to_bottom,#00000003_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none z-0" />
        
        <div className="relative mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center z-10">
          <div className="relative inline-flex items-center justify-center px-6 py-2 select-none font-doodle text-lg font-bold text-white tracking-wider uppercase animate-wiggle shrink-0 mb-4">
            <svg className="absolute inset-0 w-full h-full text-zinc-950 fill-current" viewBox="0 0 140 50" preserveAspectRatio="none">
              <path d="M5,5 C40,2 100,2 135,5 C138,15 138,35 135,45 C100,48 40,48 5,45 C2,35 2,15 5,5 Z" />
              <path d="M65,44 L70,51 L75,44 Z" />
            </svg>
            <span className="relative z-10 pt-0.5">Our Work</span>
          </div>

          <h1 className="mt-4 font-doodle text-4xl sm:text-6xl font-extrabold text-zinc-900 leading-tight">
            Projects that deliver <span className="inline-block text-white mt-1 pb-1 sm:pb-2" style={{ WebkitTextStroke: '1.5px #09152e', textShadow: '2.5px 2.5px 0px #09152e' }}>results.</span>
          </h1>
          <p className="mt-6 text-slate-600 font-semibold text-lg sm:text-xl max-w-2xl mx-auto">
            From high-converting e-commerce stores to lead-generating websites, explore how we help brands grow online.
          </p>
        </div>
      </section>

      {/* PROJECTS GRID */}
      <section className="py-24 bg-white relative">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-12 md:grid-cols-2">
            {projects.map((p) => (
              <div key={p.title} className="group relative overflow-hidden rounded-3xl border-2 border-zinc-950 bg-white shadow-[4px_4px_0px_#09152e] hover:shadow-[6px_6px_0px_#09152e] hover:-translate-x-0.5 hover:-translate-y-0.5 transition-all duration-300 flex flex-col justify-start">
                
                {/* Image Section */}
                <div className="relative aspect-[16/10] overflow-hidden border-b-2 border-zinc-950 select-none pointer-events-none">
                  <Image
                    src={p.image}
                    alt={p.title}
                    fill
                    sizes="(max-width: 768px) 100vw, 50vw"
                    className="object-cover group-hover:scale-[1.03] transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-black/5 group-hover:bg-black/10 transition-colors" />
                  
                  {/* Status Tag */}
                  <div className="absolute top-4 right-4 z-10">
                    <span className="inline-flex items-center rounded-full border-2 border-zinc-950 bg-zinc-950 text-white font-doodle text-[10px] font-black uppercase tracking-wider px-3 py-1.5 shadow-[2px_2px_0px_#fbbf24]">
                      {p.status}
                    </span>
                  </div>
                </div>

                {/* Info Section */}
                <div className="p-8 flex flex-col justify-between flex-grow">
                  <div>
                    <div className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">
                      {p.category}
                    </div>
                    <h2 className="font-doodle font-black text-2xl text-zinc-950 leading-tight mb-4">{p.title}</h2>
                    <p className="text-sm/relaxed text-slate-600 font-semibold mb-6">
                      {p.desc}
                    </p>
                  </div>
                  
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
                    <ExternalLink className="w-4 h-4 shrink-0" /> 
                    <span>Case Study coming soon</span>
                  </div>
                </div>

              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Bottom Section */}
      <section className="py-24 border-y-4 border-zinc-950 bg-white relative overflow-hidden">
        {/* Dotted mesh grid */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#00000003_1px,transparent_1px),linear-gradient(to_bottom,#00000003_1px,transparent_1px)] bg-[size:18px_18px] pointer-events-none z-0" />
        
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className="font-doodle text-4xl sm:text-5xl font-extrabold text-zinc-950">Have a project in mind?</h2>
          <p className="mt-6 text-slate-600 font-semibold text-lg max-w-xl mx-auto">
            Let's build something amazing together. Get a free consultation and let's discuss your goals.
          </p>
          
          <div className="mt-10">
            <Link href="/contact" className="inline-flex h-14 items-center justify-center px-10 rounded-full border-2 border-zinc-950 bg-zinc-950 text-white font-doodle font-black text-lg hover:bg-white hover:text-zinc-950 transition-all duration-300 shadow-[4px_4px_0px_#fbbf24] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 select-none">
              Start Your Project Today <ArrowRight className="w-5 h-5 ml-2" />
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
