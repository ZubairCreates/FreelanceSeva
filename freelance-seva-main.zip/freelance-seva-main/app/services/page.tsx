"use client";

import Link from "next/link";
import { ArrowRight } from "lucide-react";

// --- ILLUSTRATIONS FOR EACH SERVICE (STUNNING INTERACTIVE SVGS WITH SCOPED STYLES) ---

function WebEngineIllustration() {
  return (
    <div className="relative w-full max-w-[420px] md:max-w-[480px] aspect-square mx-auto flex items-center justify-center group/ill select-none">
      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes float-window {
          0%, 100% { transform: translateY(0px) rotate(-1deg); }
          50% { transform: translateY(-5px) rotate(1deg); }
        }
        @keyframes spin-react {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        @keyframes blink-cursor {
          0%, 100% { opacity: 0; }
          50% { opacity: 1; }
        }
        @keyframes flicker-code {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 1; }
        }
        .ill-window { animation: float-window 4s ease-in-out infinite; }
        .ill-react-core { transform-origin: center; animation: spin-react 12s linear infinite; }
        .ill-cursor { animation: blink-cursor 1s step-end infinite; }
        .ill-code-line { animation: flicker-code 1.5s infinite; }
        .ill-box { transition: transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
        .group\\/ill:hover .ill-box { transform: translate(6px, -6px) scale(1.05); }
        .ill-pointer { transition: transform 0.3s ease; }
        .group\\/ill:hover .ill-pointer { transform: translate(-3px, -3px); }
      `}} />

      {/* Sketched brackets & sparkles floating around browser */}
      <svg className="absolute inset-0 w-full h-full text-zinc-900/10 pointer-events-none overflow-visible" viewBox="0 0 200 200">
        {/* Floating '< />' tag */}
        <text x="25" y="45" fontSize="18" fontWeight="bold" fontFamily="monospace" transform="rotate(-15 25 45)">&lt; /&gt;</text>
        {/* Floating sparkles */}
        <path d="M165,35 L165,41 M159,38 L169,38" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        <path d="M25,155 L25,161 M19,158 L29,158" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      </svg>

      {/* Interactive Web Builder Browser */}
      <svg className="w-full h-full max-w-[420px] max-h-[420px] md:max-w-[480px] md:max-h-[480px] text-zinc-950 overflow-visible" viewBox="0 0 200 200">
        {/* Browser window container */}
        <g className="ill-window" style={{ transformOrigin: "100px 100px" }}>
          {/* Main browser card shadow */}
          <rect x="34" y="39" width="136" height="126" rx="8" fill="none" stroke="currentColor" strokeWidth="4" />
          {/* Main browser card body */}
          <rect x="30" y="35" width="136" height="126" rx="8" fill="#fff" stroke="currentColor" strokeWidth="3" />

          {/* Browser header bar */}
          <line x1="30" y1="58" x2="166" y2="58" stroke="currentColor" strokeWidth="3" />
          
          {/* Windows controls (Red, Yellow, Green dots) */}
          <circle cx="44" cy="46" r="3" fill="#ef4444" stroke="currentColor" strokeWidth="1.5" />
          <circle cx="54" cy="46" r="3" fill="#fbbf24" stroke="currentColor" strokeWidth="1.5" />
          <circle cx="64" cy="46" r="3" fill="#10b981" stroke="currentColor" strokeWidth="1.5" />

          {/* Address Bar mock */}
          <rect x="76" y="41" width="76" height="10" rx="3" fill="#f1f5f9" stroke="currentColor" strokeWidth="1.5" />
          <line x1="82" y1="46" x2="112" y2="46" stroke="currentColor" strokeWidth="1" opacity="0.4" />

          {/* Web interface layout grid inside browser */}
          {/* Hero section mock */}
          <rect x="38" y="66" width="120" height="26" rx="4" fill="#f8fafc" stroke="currentColor" strokeWidth="2" />
          <line x1="46" y1="74" x2="106" y2="74" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <line x1="46" y1="80" x2="78" y2="80" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" opacity="0.5" />

          {/* Animated 3D Floating Grid Box */}
          <g className="ill-box" style={{ transformOrigin: "125px 79px" }}>
            <rect x="116" y="71" width="36" height="16" rx="3" fill="#fbbf24" stroke="currentColor" strokeWidth="2.5" />
            {/* Inner highlights */}
            <line x1="122" y1="79" x2="146" y2="79" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </g>

          {/* Bottom columns layout */}
          <rect x="38" y="98" width="56" height="34" rx="4" fill="#f8fafc" stroke="currentColor" strokeWidth="2" />
          <circle cx="50" cy="110" r="6" fill="#60a5fa" stroke="currentColor" strokeWidth="1.5" />
          <line x1="62" y1="108" x2="86" y2="108" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <line x1="62" y1="114" x2="78" y2="114" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" opacity="0.4" />

          <rect x="102" y="98" width="56" height="34" rx="4" fill="#f8fafc" stroke="currentColor" strokeWidth="2" />
          <circle cx="114" cy="110" r="6" fill="#34d399" stroke="currentColor" strokeWidth="1.5" />
          <line x1="126" y1="108" x2="150" y2="108" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <line x1="126" y1="114" x2="142" y2="114" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" opacity="0.4" />

          {/* Console / Terminal line at very bottom */}
          <rect x="38" y="138" width="120" height="16" rx="3" fill="#27272a" stroke="currentColor" strokeWidth="2" />
          <text x="44" y="149" fill="#10b981" fontSize="6" fontWeight="bold" fontFamily="monospace" className="ill-code-line">&gt; npm run dev - ready in 150ms</text>

          {/* Interactive Mouse pointer selecting floating block */}
          <g className="ill-pointer" transform="translate(138, 92)">
            <path d="M0,0 L12,12 L7,13 L10,19 L7,20 L4,14 L0,17 Z" fill="#fff" stroke="currentColor" strokeWidth="2.5" strokeLinejoin="round" />
            <circle cx="0" cy="0" r="1.5" fill="#ef4444" />
          </g>
        </g>

        {/* Orbiting React Core Atom in foreground */}
        <g className="ill-react-core" transform="translate(100, 96)">
          {/* Orbital rings */}
          <ellipse cx="0" cy="0" rx="30" ry="10" fill="none" stroke="currentColor" strokeWidth="2" opacity="0.75" transform="rotate(30)" />
          <ellipse cx="0" cy="0" rx="30" ry="10" fill="none" stroke="currentColor" strokeWidth="2" opacity="0.75" transform="rotate(90)" />
          <ellipse cx="0" cy="0" rx="30" ry="10" fill="none" stroke="currentColor" strokeWidth="2" opacity="0.75" transform="rotate(150)" />
          
          {/* Central neon glowing atom */}
          <circle cx="0" cy="0" r="6" fill="#00f0ff" stroke="currentColor" strokeWidth="2.5" />
          {/* Pulsing highlights */}
          <circle cx="0" cy="0" r="2" fill="#fff" />
        </g>
      </svg>
    </div>
  );
}

function CartEngineIllustration() {
  return (
    <div className="relative w-full max-w-[420px] md:max-w-[480px] aspect-square mx-auto flex items-center justify-center group/ill select-none">
      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes float-card {
          0%, 100% { transform: translateY(0px) rotate(4deg); }
          50% { transform: translateY(-8px) rotate(1deg); }
        }
        @keyframes wiggle-cart {
          0%, 100% { transform: rotate(0deg) translateX(0px); }
          25% { transform: rotate(-1deg) translateX(-2px); }
          75% { transform: rotate(1deg) translateX(2px); }
        }
        @keyframes rotate-coin {
          0%, 100% { transform: scale(1) rotateY(0deg); }
          50% { transform: scale(1.08) rotateY(180deg); }
        }
        @keyframes flash-star {
          0%, 100% { opacity: 0.4; }
          50% { opacity: 1; }
        }
        .ill-card { animation: float-card 4s ease-in-out infinite; }
        .ill-cart { animation: wiggle-cart 3s ease-in-out infinite; transform-origin: bottom center; }
        .ill-coin { transform-origin: center; animation: rotate-coin 4s ease-in-out infinite; }
        .ill-star-pulse { animation: flash-star 1.5s infinite; }
        .ill-wheel { transition: transform 0.4s ease; transform-origin: center; }
        .group\\/ill:hover .ill-wheel { transform: rotate(120deg); }
        .ill-tag { transition: transform 0.3s ease; transform-origin: top right; }
        .group\\/ill:hover .ill-tag { transform: rotate(-15deg); }
      `}} />

      {/* Floating Sparkles & Dash Flows */}
      <svg className="absolute inset-0 w-full h-full text-zinc-900/10 pointer-events-none overflow-visible" viewBox="0 0 200 200">
        {/* Curving dashed transaction route */}
        <path d="M25,120 Q65,60 145,75" fill="none" stroke="currentColor" strokeWidth="2.5" strokeDasharray="6 6" />
        <path d="M140,70 L146,76 L139,81" fill="none" stroke="currentColor" strokeWidth="2.5" />
        
        {/* Floating Sparkle stars */}
        <g className="ill-star-pulse text-[#fbbf24] fill-current">
          <path d="M25,65 L28,70 L33,71 L29,75 L30,80 L25,77 L20,80 L21,75 L17,71 L22,70 Z" />
          <path d="M175,125 L177,128 L181,129 L178,131 L179,134 L175,132 L171,134 L172,131 L169,129 L173,128 Z" style={{ animationDelay: '0.5s' }} />
        </g>
      </svg>

      {/* Interactive eCommerce Shopping Engine */}
      <svg className="w-full h-full max-w-[420px] max-h-[420px] md:max-w-[480px] md:max-h-[480px] text-zinc-950 overflow-visible" viewBox="0 0 200 200">
        {/* Dash Grid guidelines */}
        <g stroke="#0000000a" strokeWidth="1.5">
          <line x1="20" y1="100" x2="180" y2="100" />
          <line x1="100" y1="20" x2="100" y2="180" />
        </g>

        {/* 1. Shopping Cart Group */}
        <g className="ill-cart" style={{ transformOrigin: "80px 145px" }}>
          {/* Basket Mesh shadow */}
          <path d="M48,82 L108,82 L98,124 L56,124 Z" fill="none" stroke="currentColor" strokeWidth="4" />
          {/* Basket main body */}
          <path d="M44,78 L108,78 L98,122 L52,122 Z" fill="#fff" stroke="currentColor" strokeWidth="3" strokeLinejoin="round" />
          
          {/* Grid lines inside shopping cart */}
          <line x1="64" y1="78" x2="64" y2="122" stroke="currentColor" strokeWidth="1.5" />
          <line x1="76" y1="78" x2="76" y2="122" stroke="currentColor" strokeWidth="1.5" />
          <line x1="88" y1="78" x2="88" y2="122" stroke="currentColor" strokeWidth="1.5" />
          <line x1="98" y1="78" x2="92" y2="122" stroke="currentColor" strokeWidth="1.5" />
          <line x1="49" y1="92" x2="104" y2="92" stroke="currentColor" strokeWidth="1.5" />
          <line x1="51" y1="106" x2="100" y2="106" stroke="currentColor" strokeWidth="1.5" />

          {/* Cart handle */}
          <path d="M44,84 L32,84 L26,62 L16,62" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
          <circle cx="16" cy="62" r="2.5" fill="currentColor" />

          {/* Bottom chassis */}
          <path d="M52,122 L98,122 L92,136 L56,136 Z" fill="#e4e4e7" stroke="currentColor" strokeWidth="2.5" />

          {/* Cart Wheels */}
          <g className="ill-wheel" style={{ transformOrigin: "60px 146px" }}>
            <circle cx="60" cy="146" r="8" fill="#fff" stroke="currentColor" strokeWidth="2.5" />
            <circle cx="60" cy="146" r="3" fill="currentColor" />
            <line x1="60" y1="138" x2="60" y2="154" stroke="currentColor" strokeWidth="1" />
          </g>
          <g className="ill-wheel" style={{ transformOrigin: "88px 146px" }}>
            <circle cx="88" cy="146" r="8" fill="#fff" stroke="currentColor" strokeWidth="2.5" />
            <circle cx="88" cy="146" r="3" fill="currentColor" />
            <line x1="88" y1="138" x2="88" y2="154" stroke="currentColor" strokeWidth="1" />
          </g>
        </g>

        {/* 2. Interactive Floating Price Tag (hanging from cart) */}
        <g className="ill-tag" transform="translate(108, 92) rotate(-8 108 92)">
          <rect x="-6" y="0" width="22" height="32" rx="4" fill="#fbbf24" stroke="currentColor" strokeWidth="2.5" />
          <circle cx="5" cy="6" r="2" fill="#fff" stroke="currentColor" strokeWidth="1.5" />
          <text x="5" y="22" fill="currentColor" fontSize="11" fontWeight="extrabold" fontFamily="monospace" textAnchor="middle">%</text>
        </g>

        {/* 3. Golden Transaction Star Coin (floating in/above cart) */}
        <g className="ill-coin" transform="translate(76, 62)">
          <circle cx="0" cy="0" r="18" fill="#fbbf24" stroke="currentColor" strokeWidth="3" />
          <circle cx="0" cy="0" r="14" fill="none" stroke="currentColor" strokeWidth="1.5" strokeDasharray="3 3" />
          {/* Dollar symbol inside coin */}
          <text x="0" y="5" fill="currentColor" fontSize="16" fontWeight="black" fontFamily="sans-serif" textAnchor="middle">$</text>
        </g>

        {/* 4. Premium Floating Credit Card */}
        <g className="ill-card" style={{ transformOrigin: "136px 115px" }}>
          {/* Card Shadow */}
          <rect x="98" y="99" width="76" height="48" rx="6" fill="none" stroke="currentColor" strokeWidth="3.5" />
          {/* Card Body */}
          <rect x="94" y="95" width="76" height="48" rx="6" fill="#fff" stroke="currentColor" strokeWidth="2.5" />
          
          {/* Sketched credit card magnetic strip */}
          <line x1="94" y1="108" x2="170" y2="108" stroke="currentColor" strokeWidth="3" />
          
          {/* Credit card chip */}
          <rect x="104" y="117" width="12" height="9" rx="2" fill="#fbbf24" stroke="currentColor" strokeWidth="1.5" />
          <line x1="110" y1="117" x2="110" y2="126" stroke="currentColor" strokeWidth="1" />
          <line x1="104" y1="121" x2="116" y2="121" stroke="currentColor" strokeWidth="1" />

          {/* Secure lock or Card holder name representation lines */}
          <line x1="104" y1="134" x2="128" y2="134" stroke="currentColor" strokeWidth="2" strokeLinecap="round" opacity="0.4" />
          <line x1="136" y1="134" x2="148" y2="134" stroke="currentColor" strokeWidth="2" strokeLinecap="round" opacity="0.4" />

          {/* Transaction Successful neon Green Approved Badge */}
          <g transform="translate(162, 92)">
            <circle cx="0" cy="0" r="11" fill="#10b981" stroke="currentColor" strokeWidth="2.5" />
            {/* White Checkmark inside */}
            <path d="M-5,0 L-1,4 L5,-3" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function MountainIllustration() {
  return (
    <div className="relative w-full max-w-[420px] md:max-w-[480px] aspect-square mx-auto flex items-center justify-center group/ill select-none">
      <style dangerouslySetInnerHTML={{
        __html: `
        @keyframes float-flag {
          0%, 100% { transform: rotate(0deg); }
          50% { transform: rotate(6deg); }
        }
        @keyframes scan-glass {
          0%, 100% { transform: translate(0px, 0px); }
          33% { transform: translate(15px, -10px); }
          66% { transform: translate(-10px, 15px); }
        }
        .ill-flag { animation: float-flag 2s ease-in-out infinite; }
        .ill-glass { animation: scan-glass 6s ease-in-out infinite; }
        .ill-star { transition: transform 0.4s ease; }
        .group\\/ill:hover .ill-star { transform: scale(1.3) rotate(15deg); }
        .ill-line { stroke-dasharray: 100; stroke-dashoffset: 100; transition: stroke-dashoffset 1s ease; }
        .group\\/ill:hover .ill-line { stroke-dashoffset: 0; }
      `}} />

      <svg className="w-full h-full max-w-[420px] max-h-[420px] md:max-w-[480px] md:max-h-[480px] text-zinc-950 overflow-visible" viewBox="0 0 200 200">
        {/* Sun in background */}
        <circle cx="50" cy="55" r="18" fill="none" stroke="currentColor" strokeWidth="2.5" strokeDasharray="4 4" />
        <circle cx="50" cy="55" r="12" fill="#fef08a" stroke="currentColor" strokeWidth="2.5" />

        {/* Mountain Base */}
        <path d="M15,160 L75,70 L110,120 L155,50 L190,160 Z" fill="#f4f4f5" stroke="currentColor" strokeWidth="3" strokeLinejoin="round" />

        {/* Mountain Ridge shading */}
        <path d="M75,70 L90,160" stroke="currentColor" strokeWidth="2" strokeDasharray="3 3" />
        <path d="M155,50 L168,160" stroke="currentColor" strokeWidth="2" />
        <path d="M110,120 L122,160" stroke="currentColor" strokeWidth="1.5" strokeDasharray="2 2" />

        {/* Ascending SEO trajectory arrow line */}
        <path d="M25,145 C65,130 90,80 145,55" className="ill-line" fill="none" stroke="#10b981" strokeWidth="4" strokeLinecap="round" />
        <path d="M140,53 L150,53 L147,62 Z" fill="#10b981" stroke="#10b981" strokeWidth="1.5" />

        {/* Peak Flag (animated) */}
        <g className="ill-flag" style={{ transformOrigin: "155px 50px" }}>
          {/* Flagpole */}
          <line x1="155" y1="50" x2="155" y2="25" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
          {/* Flag banner */}
          <path d="M155,27 L185,32 L155,39 Z" fill="#27272a" stroke="currentColor" strokeWidth="2.5" />
          <text x="166" y="36" fill="#fff" fontSize="6" fontWeight="bold" fontFamily="sans-serif">#1</text>
        </g>

        {/* SEO Stars in sky */}
        <g className="ill-star" style={{ transformOrigin: "115px 45px" }}>
          {/* Star 1 */}
          <path d="M115,35 L117,41 L123,41 L118,45 L120,51 L115,47 L110,51 L112,45 L107,41 L113,41 Z" fill="#fbbf24" stroke="currentColor" strokeWidth="1.5" />
          {/* Spark sparkles */}
          <path d="M102,32 L98,28" stroke="currentColor" strokeWidth="1.5" />
          <path d="M130,28 L134,24" stroke="currentColor" strokeWidth="1.5" />
        </g>

        {/* Magnifying Glass (Search Engine Scanning) */}
        <g className="ill-glass" style={{ transformOrigin: "90px 105px" }}>
          {/* Handle */}
          <line x1="108" y1="123" x2="128" y2="143" stroke="currentColor" strokeWidth="5.5" strokeLinecap="round" />
          <line x1="108" y1="123" x2="128" y2="143" stroke="#fff" strokeWidth="2" strokeLinecap="round" />

          {/* Glass rim */}
          <circle cx="90" cy="105" r="24" fill="#fff" fillOpacity="0.85" stroke="currentColor" strokeWidth="3.5" />
          {/* Inner reflection */}
          <path d="M76,98 A16,16 0 0,1 100,90" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" opacity="0.3" />

          {/* Mini radar scanner inside glass */}
          <circle cx="90" cy="105" r="8" fill="none" stroke="#ef4444" strokeWidth="2" strokeDasharray="3 3" />
          <circle cx="90" cy="105" r="2" fill="#ef4444" />
        </g>
      </svg>
    </div>
  );
}

function PhoneIllustration() {
  return (
    <div className="relative w-full max-w-[420px] md:max-w-[480px] aspect-square mx-auto flex items-center justify-center group/ill select-none">
      <style dangerouslySetInnerHTML={{
        __html: `
        @keyframes float-emoji {
          0% { transform: translateY(0px) scale(0.6); opacity: 0; }
          20% { opacity: 1; }
          100% { transform: translateY(-45px) scale(1.1); opacity: 0; }
        }
        @keyframes phone-vibe {
          0%, 100% { transform: rotate(-2deg); }
          50% { transform: rotate(2deg); }
        }
        .ill-emoji-1 { animation: float-emoji 2.5s ease-out infinite; }
        .ill-emoji-2 { animation: float-emoji 2.8s ease-out infinite; animation-delay: 0.7s; }
        .ill-emoji-3 { animation: float-emoji 3.1s ease-out infinite; animation-delay: 1.4s; }
        .ill-phone { animation: phone-vibe 4s ease-in-out infinite; }
        .group\\/ill:hover .ill-phone { animation: phone-vibe 0.5s ease-in-out infinite; }
      `}} />

      <svg className="w-full h-full max-w-[420px] max-h-[420px] md:max-w-[480px] md:max-h-[480px] text-zinc-950 overflow-visible" viewBox="0 0 200 200">
        {/* Floating social emojis */}
        <g transform="translate(90, 45)">
          {/* Like Emoji bubble */}
          <g className="ill-emoji-1" style={{ transformOrigin: "0px 0px" }}>
            <circle cx="-25" cy="-5" r="10" fill="#3b82f6" stroke="currentColor" strokeWidth="1.5" />
            <text x="-25" y="-1.5" fill="#fff" fontSize="10" textAnchor="middle">👍</text>
          </g>
          {/* Heart Emoji bubble */}
          <g className="ill-emoji-2" style={{ transformOrigin: "0px 0px" }}>
            <circle cx="15" cy="-25" r="11" fill="#ef4444" stroke="currentColor" strokeWidth="1.5" />
            <text x="15" y="-21.5" fill="#fff" fontSize="11" textAnchor="middle">❤️</text>
          </g>
          {/* Fire Emoji bubble */}
          <g className="ill-emoji-3" style={{ transformOrigin: "0px 0px" }}>
            <circle cx="28" cy="15" r="10" fill="#f59e0b" stroke="currentColor" strokeWidth="1.5" />
            <text x="28" y="18.5" fill="#fff" fontSize="10" textAnchor="middle">🔥</text>
          </g>
        </g>

        {/* Smartphone body */}
        <g className="ill-phone" style={{ transformOrigin: "100px 110px" }}>
          {/* Shadow outline */}
          <rect x="67" y="47" width="66" height="116" rx="14" fill="none" stroke="currentColor" strokeWidth="4" />
          {/* Main phone body */}
          <rect x="63" y="43" width="66" height="116" rx="14" fill="#fff" stroke="currentColor" strokeWidth="3" />

          {/* Screen area */}
          <rect x="69" y="55" width="54" height="92" rx="6" fill="#f8fafc" stroke="currentColor" strokeWidth="2" />

          {/* Speaker ear piece */}
          <line x1="88" y1="49" x2="104" y2="49" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />

          {/* Front camera lens */}
          <circle cx="82" cy="49" r="1.5" fill="currentColor" />

          {/* Social feed card mockup inside screen */}
          <g transform="translate(73, 62)">
            {/* User avatar circle */}
            <circle cx="8" cy="8" r="6" fill="#e2e8f0" stroke="currentColor" strokeWidth="1.5" />
            {/* Title block line */}
            <line x1="18" y1="5" x2="42" y2="5" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
            <line x1="18" y1="10" x2="32" y2="10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" opacity="0.4" />

            {/* Main graphic block */}
            <rect x="2" y="20" width="46" height="34" rx="4" fill="#e2e8f0" stroke="currentColor" strokeWidth="1.5" />
            {/* Tilted vector landscape inside post */}
            <path d="M6,48 L18,36 L30,46 L40,32 L46,45" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />

            {/* Like & reply bar */}
            <circle cx="8" cy="62" r="3" fill="#ef4444" />
            <line x1="16" y1="62" x2="38" y2="62" stroke="currentColor" strokeWidth="2" opacity="0.6" />
          </g>

          {/* Active status bubble */}
          <circle cx="120" cy="58" r="5" fill="#10b981" stroke="currentColor" strokeWidth="2" />
          {/* Home button */}
          <circle cx="96" cy="152" r="4.5" fill="none" stroke="currentColor" strokeWidth="2" />
        </g>

        {/* Hand holding phone from left */}
        <g transform="translate(15, 110)">
          {/* Arm sleeve */}
          <path d="M5,42 C15,38 38,36 48,36 C52,36 48,46 48,46" fill="none" stroke="currentColor" strokeWidth="3" />
          {/* Sketched thumb holding screen edge */}
          <path d="M48,36 C55,36 58,42 58,45 C58,48 53,50 48,50" fill="#fff" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
        </g>
      </svg>
    </div>
  );
}

function TargetIllustration() {
  return (
    <div className="relative w-full max-w-[420px] md:max-w-[480px] aspect-square mx-auto flex items-center justify-center group/ill select-none">
      <style dangerouslySetInnerHTML={{
        __html: `
        @keyframes vibe-target {
          0%, 100% { transform: scale(1) rotate(0deg); }
          50% { transform: scale(1.02) rotate(1deg); }
        }
        @keyframes float-dollar {
          0% { transform: translateY(0px) scale(0.7); opacity: 0; }
          25% { opacity: 1; }
          100% { transform: translateY(-40px) scale(1.1); opacity: 0; }
        }
        .ill-target { transform-origin: center; animation: vibe-target 4s ease-in-out infinite; }
        .ill-dollar-1 { animation: float-dollar 2s ease-out infinite; }
        .ill-dollar-2 { animation: float-dollar 2.4s ease-out infinite; animation-delay: 0.8s; }
        .ill-dart { transition: transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
        .group\\/ill:hover .ill-dart { transform: scale(1.15) translate(-4px, 4px) rotate(-3deg); }
      `}} />

      <svg className="w-full h-full max-w-[420px] max-h-[420px] md:max-w-[480px] md:max-h-[480px] text-zinc-950 overflow-visible" viewBox="0 0 200 200">
        {/* Floating dollars symbols */}
        <g transform="translate(68, 55)">
          <g className="ill-dollar-1">
            <text x="0" y="0" fill="#10b981" fontSize="14" fontWeight="bold" fontFamily="sans-serif">$</text>
          </g>
        </g>
        <g transform="translate(132, 45)">
          <g className="ill-dollar-2">
            <text x="0" y="0" fill="#10b981" fontSize="12" fontWeight="bold" fontFamily="sans-serif">$</text>
          </g>
        </g>

        {/* Tilted target board (Main visual) */}
        <g className="ill-target">
          {/* Target stand leg back */}
          <line x1="100" y1="120" x2="100" y2="175" stroke="currentColor" strokeWidth="5.5" strokeLinecap="round" />
          <line x1="70" y1="120" x2="50" y2="170" stroke="currentColor" strokeWidth="4.5" strokeLinecap="round" />
          <line x1="130" y1="120" x2="150" y2="170" stroke="currentColor" strokeWidth="4.5" strokeLinecap="round" />

          {/* Outer ring shadow */}
          <circle cx="100" cy="95" r="54" fill="none" stroke="currentColor" strokeWidth="4" />

          {/* Target wooden board */}
          <circle cx="96" cy="91" r="54" fill="#fdfcfa" stroke="currentColor" strokeWidth="3" />

          {/* Middle Ring */}
          <circle cx="96" cy="91" r="38" fill="none" stroke="currentColor" strokeWidth="3" />
          <circle cx="96" cy="91" r="38" fill="#fca5a5" stroke="currentColor" strokeWidth="0" />

          {/* Inner ring */}
          <circle cx="96" cy="91" r="22" fill="none" stroke="currentColor" strokeWidth="2.5" />
          <circle cx="96" cy="91" r="22" fill="#ef4444" stroke="currentColor" strokeWidth="0" />

          {/* Bullseye point */}
          <circle cx="96" cy="91" r="8" fill="#27272a" stroke="currentColor" strokeWidth="2" />
        </g>

        {/* High Conversion Darts hitting target directly in center */}
        <g className="ill-dart" style={{ transformOrigin: "96px 91px" }}>
          {/* Dart 1 (Stuck in bullseye) */}
          {/* Shaft */}
          <line x1="60" y1="127" x2="94" y2="93" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
          {/* Flights */}
          <path d="M50,137 L58,139 L54,129 Z" fill="#27272a" stroke="currentColor" strokeWidth="1.5" />
          <path d="M49,138 L43,144 L53,142 Z" fill="#ef4444" stroke="currentColor" strokeWidth="1.5" />
          {/* Metallic barrel */}
          <rect x="80" y="101" width="8" height="4" rx="1" fill="#e4e4e7" stroke="currentColor" strokeWidth="1.5" transform="rotate(-45 80 101)" />

          {/* Spark sparkles around hit */}
          <path d="M96,75 L96,81" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          <path d="M112,91 L106,91" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          <path d="M106,81 L102,85" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
        </g>
      </svg>
    </div>
  );
}

function PaletteIllustration() {
  return (
    <div className="relative w-full max-w-[420px] md:max-w-[480px] aspect-square mx-auto flex items-center justify-center group/ill select-none">
      <style dangerouslySetInnerHTML={{
        __html: `
        @keyframes float-palette {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-5px) rotate(1deg); }
        }
        @keyframes stroke-brush {
          0%, 100% { transform: translate(0px, 0px) rotate(0deg); }
          50% { transform: translate(12px, -8px) rotate(8deg); }
        }
        .ill-palette { animation: float-palette 4s ease-in-out infinite; }
        .ill-brush { transform-origin: 130px 110px; animation: stroke-brush 3.5s ease-in-out infinite; }
        .ill-sparkle { transition: transform 0.4s ease; }
        .group\\/ill:hover .ill-sparkle { transform: scale(1.3) rotate(30deg); }
      `}} />

      <svg className="w-full h-full max-w-[420px] max-h-[420px] md:max-w-[480px] md:max-h-[480px] text-zinc-950 overflow-visible" viewBox="0 0 200 200">
        {/* Swirling brand brushstroke in background */}
        <path d="M35,120 C75,100 135,160 175,110" fill="none" stroke="#fbbf24" strokeWidth="6" strokeLinecap="round" opacity="0.3" />

        {/* Sketched Artist Palette */}
        <g className="ill-palette" style={{ transformOrigin: "90px 105px" }}>
          {/* Shadow ring */}
          <path d="M44,80 C44,52 74,40 104,40 C134,40 154,58 154,88 C154,118 129,143 99,143 C91,143 85,138 84,130 C83,120 74,120 64,120 C54,120 44,108 44,80 Z" fill="none" stroke="currentColor" strokeWidth="4" />

          {/* Main palette board */}
          <path d="M40,76 C40,48 70,36 100,36 C130,36 150,54 150,84 C150,114 125,139 95,139 C87,139 81,134 80,126 C79,116 70,116 60,116 C50,116 40,104 40,76 Z" fill="#fff" stroke="currentColor" strokeWidth="3" />

          {/* Thumb hole */}
          <ellipse cx="125" cy="80" rx="7" ry="9" fill="#27272a" stroke="currentColor" strokeWidth="2" />

          {/* Dynamic dabs of creative colors */}
          {/* Cyan Dab */}
          <circle cx="58" cy="62" r="8" fill="#22d3ee" stroke="currentColor" strokeWidth="2.5" />
          {/* Yellow Dab */}
          <circle cx="78" cy="52" r="7" fill="#fde047" stroke="currentColor" strokeWidth="2.5" />
          {/* Emerald Dab */}
          <circle cx="102" cy="48" r="8" fill="#34d399" stroke="currentColor" strokeWidth="2.5" />
          {/* Pink Dab */}
          <circle cx="126" cy="56" r="7" fill="#f472b6" stroke="currentColor" strokeWidth="2.5" />
          {/* Orange Dab */}
          <circle cx="58" cy="88" r="9" fill="#fb923c" stroke="currentColor" strokeWidth="2.5" />
        </g>

        {/* Sparkles of brand design */}
        <g className="ill-sparkle" style={{ transformOrigin: "152px 42px" }}>
          <path d="M152,32 L152,36" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          <path d="M148,40 L144,40" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          <path d="M156,40 L160,40" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          <path d="M152,44 L152,48" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
        </g>

        {/* Hand-drawn Paintbrush */}
        <g className="ill-brush">
          {/* Wooden handle */}
          <line x1="88" y1="148" x2="134" y2="102" stroke="currentColor" strokeWidth="4.5" strokeLinecap="round" />
          <line x1="88" y1="148" x2="134" y2="102" stroke="#fbbf24" strokeWidth="1.5" strokeLinecap="round" />

          {/* Metal ferrule */}
          <rect x="131" y="99" width="6" height="5" fill="#e4e4e7" stroke="currentColor" strokeWidth="2.5" transform="rotate(-45 131 99)" />

          {/* Brush hairs */}
          <path d="M138,98 L148,88 L142,92 Z" fill="#ef4444" stroke="currentColor" strokeWidth="2.5" strokeLinejoin="round" />
          {/* Paint dip on tip */}
          <path d="M145,91 L148,88 L143,89 Z" fill="#22d3ee" />
        </g>
      </svg>
    </div>
  );
}

function BoxIllustration() {
  return (
    <div className="relative w-full max-w-[420px] md:max-w-[480px] aspect-square mx-auto flex items-center justify-center group/ill select-none">
      <style dangerouslySetInnerHTML={{
        __html: `
        @keyframes levitate-box {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-7px); }
        }
        @keyframes rotate-gear {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        .ill-box-container { animation: levitate-box 3s ease-in-out infinite; }
        .ill-gear { transform-origin: center; animation: rotate-gear 6s linear infinite; }
        .ill-wing-left { transition: transform 0.4s ease; transform-origin: 64px 92px; }
        .group\\/ill:hover .ill-wing-left { transform: rotate(-8deg); }
        .ill-wing-right { transition: transform 0.4s ease; transform-origin: 136px 92px; }
        .group\\/ill:hover .ill-wing-right { transform: rotate(8deg); }
      `}} />

      <svg className="w-full h-full max-w-[420px] max-h-[420px] md:max-w-[480px] md:max-h-[480px] text-zinc-950 overflow-visible" viewBox="0 0 200 200">
        {/* Logistics Dotted Route Line in background */}
        <path d="M25,120 L75,145 C95,155 125,125 155,145 L180,135" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="4 4" opacity="0.3" />
        <circle cx="25" cy="120" r="3" fill="currentColor" />
        <circle cx="180" cy="135" r="3" fill="currentColor" />

        {/* Winged Box Levitation container */}
        <g className="ill-box-container" style={{ transformOrigin: "100px 92px" }}>
          {/* Sketchy wings */}
          {/* Left wing */}
          <path d="M64,92 C45,75 25,95 18,75 C25,70 38,78 48,82 C55,85 62,88 64,92 Z" className="ill-wing-left" fill="#fff" stroke="currentColor" strokeWidth="2.5" strokeLinejoin="round" />
          {/* Right wing */}
          <path d="M136,92 C155,75 175,95 182,75 C175,70 162,78 152,82 C145,85 138,88 136,92 Z" className="ill-wing-right" fill="#fff" stroke="currentColor" strokeWidth="2.5" strokeLinejoin="round" />

          {/* Delivery Box (Isometric) */}
          {/* Left panel face */}
          <path d="M64,92 L100,110 L100,140 L64,122 Z" fill="#fff" stroke="currentColor" strokeWidth="3" strokeLinejoin="round" />

          {/* Right panel face */}
          <path d="M100,110 L136,92 L136,122 L100,140 Z" fill="#f4f4f5" stroke="currentColor" strokeWidth="3" strokeLinejoin="round" />

          {/* Top face panels folded open */}
          <path d="M64,92 L100,74 L136,92 L100,110 Z" fill="#fff" stroke="currentColor" strokeWidth="3" strokeLinejoin="round" />

          {/* Isometric taped stripes */}
          <path d="M100,110 L100,140" stroke="currentColor" strokeWidth="2" />
          <path d="M78,99 L82,131" stroke="currentColor" strokeWidth="1.5" strokeDasharray="2 2" />

          {/* Custom cargo delivery symbol inside box panel */}
          <g transform="translate(108, 102) rotate(-26 108 102)">
            <rect x="0" y="0" width="16" height="12" rx="2" fill="none" stroke="currentColor" strokeWidth="2" />
            <circle cx="4" cy="14" r="2.5" fill="currentColor" />
            <circle cx="12" cy="14" r="2.5" fill="currentColor" />
          </g>
        </g>

        {/* Rotating gear wheel of automated management */}
        <g className="ill-gear" transform="translate(100, 48)">
          <circle cx="0" cy="0" r="14" fill="none" stroke="currentColor" strokeWidth="3" />
          <circle cx="0" cy="0" r="6" fill="none" stroke="currentColor" strokeWidth="2" />
          {/* Teeth */}
          {Array.from({ length: 8 }).map((_, i) => (
            <path key={i} d="M-3,-16 L3,-16 L2,-13 L-2,-13 Z" fill="currentColor" transform={`rotate(${i * 45})`} />
          ))}
        </g>
      </svg>
    </div>
  );
}

// --- SERVICES DATA STRUCTURE MATCHING CREATIVE USER DESIGNS ---

const servicesList = [
  {
    tag: "Web Design",
    title: "Next-gen custom web design & development.",
    desc: "We engineer custom high-speed web experiences that immediately capture search traffic and turn passive users into active leads.",
    points: [
      "Bespoke modern UI/UX layouts built with React/Next.js",
      "Blazing fast speeds optimized for mobile search rankings",
      "High-conversion architecture engineered for lead generation",
    ],
    timeline: "7–14 Working Days",
    pricing: "Rs. 8,999",
    illustration: WebEngineIllustration,
    btnLabel: "Explore Web Services",
  },
  {
    tag: "eCommerce Development",
    title: "Frictionless e-commerce cart pipelines.",
    desc: "Transform your retail store into a highly optimized selling machine. We design storefronts that guide buyers seamlessly from discovery to successful checkout.",
    points: [
      "Sculpting ultra-fast product catalog structures",
      "One-click frictionless checkout flows that lower cart abandonment",
      "Complete payment gateway & multi-currency integrations",
    ],
    timeline: "10–20 Working Days",
    pricing: "Rs. 14,999",
    illustration: CartEngineIllustration,
    btnLabel: "Explore eCommerce Services",
  },
  {
    tag: "Search Engine Optimisation",
    title: "Dominate Google search rankings.",
    desc: "Through data-backed semantic audits and keyword mapping, we position your pages exactly where high-intent buyers are looking.",
    points: [
      "Comprehensive site audits that resolve indexing bottlenecks",
      "High-intent keyword discovery mapping customer search trends",
      "Strategic authority backlink architecture build",
    ],
    timeline: "Ongoing (3-month min)",
    pricing: "Rs. 4,999/month",
    illustration: MountainIllustration,
    btnLabel: "Explore SEO Campaigns",
  },
  {
    tag: "Social Media Marketing",
    title: "Organic social brand & community building.",
    desc: "We design scroll-stopping graphic patterns, interactive carousels, and high-impact vertical video reels that capture immediate attention.",
    points: [
      "Scroll-stopping asset designs reflecting your unique voice",
      "Consistent content calendars mapped to demographic trends",
      "Active community engagement to drive algorithmic boost",
    ],
    timeline: "Ongoing Monthly",
    pricing: "Rs. 3,999/month",
    illustration: PhoneIllustration,
    btnLabel: "Explore Social Services",
  },
  {
    tag: "Paid Advertising",
    title: "High-performance precision paid ads.",
    desc: "Eliminate wasteful ad spend. We architect paid ad funnels across Google, Meta, and LinkedIn targeting highly qualified buying audiences.",
    points: [
      "Rigorous competitor research targeting market gaps",
      "Hyper-focused lookalike & interest target mapping",
      "Rapid A/B creative copywriting and visual testing",
    ],
    timeline: "Setup in 3–5 Days",
    pricing: "Rs. 2,999/month",
    illustration: TargetIllustration,
    btnLabel: "Explore Paid Campaigns",
  },
  {
    tag: "Brand Identity",
    title: "Bespoke premium brand design systems.",
    desc: "We craft cohesive brand design guidelines including custom typography scales, curated color palettes, and versatile vector logo marks.",
    points: [
      "Multiple conceptual directions for visual review",
      "Cohesive type guidelines and tailored color models",
      "High-fidelity modern vector asset sets for digital scale",
    ],
    timeline: "5–7 Working Days",
    pricing: "Rs. 2,499",
    illustration: PaletteIllustration,
    btnLabel: "Explore Brand Identity",
  },
  {
    tag: "eCommerce Management",
    title: "Professional marketplace store operations.",
    desc: "Accelerate your merchant volume across major online retail ecosystems like Amazon, Flipkart, and Meesho without catalog bottlenecks.",
    points: [
      "Search-optimized product copywriting driving catalog discovery",
      "Professional visual optimization for gallery and listing graphics",
      "End-to-end store listings and variation configuration",
    ],
    timeline: "Setup in 2–5 Days",
    pricing: "Rs. 1,999/month",
    illustration: BoxIllustration,
    btnLabel: "Explore Merchant Services",
  },
];

const processList = [
  { step: "01", title: "Discovery Call", desc: "We understand your business, goals, and target audience in a free 30-minute consultation." },
  { step: "02", title: "Proposal & Agreement", desc: "You receive a clear scope of work, timeline, and pricing with no hidden charges." },
  { step: "03", title: "Design & Development", desc: "Our team begins work with regular updates and milestone check-ins throughout the project." },
  { step: "04", title: "Review & Revisions", desc: "You review the work, provide feedback, and we refine until you are fully satisfied." },
  { step: "05", title: "Launch & Handover", desc: "We go live, provide training if required, and remain available for post-launch support." },
];

export default function Services() {
  return (
    <>
      {/* HEADER SECTION WITH SKETCHY THEME */}
      <section className="bg-white border-b-4 border-zinc-950 py-24 relative overflow-hidden">
        {/* Grid paper mesh blueprint background */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#00000003_1px,transparent_1px),linear-gradient(to_bottom,#00000003_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none z-0" />

        <div className="relative mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center z-10">
          <div className="relative inline-flex items-center justify-center px-6 py-2 select-none font-doodle text-lg font-bold text-white tracking-wider uppercase animate-wiggle shrink-0 mb-4">
            <svg className="absolute inset-0 w-full h-full text-zinc-950 fill-current" viewBox="0 0 140 50" preserveAspectRatio="none">
              <path d="M5,5 C40,2 100,2 135,5 C138,15 138,35 135,45 C100,48 40,48 5,45 C2,35 2,15 5,5 Z" />
              <path d="M65,44 L70,51 L75,44 Z" />
            </svg>
            <span className="relative z-10 pt-0.5">What we offer</span>
          </div>

          <h1 className="mt-4 font-doodle text-4xl sm:text-6xl font-extrabold text-zinc-900 leading-tight">
            Services that drive <span className="inline-block text-white mt-1 pb-1 sm:pb-2" style={{ WebkitTextStroke: '1.5px #09152e', textShadow: '2.5px 2.5px 0px #09152e' }}>real growth.</span>
          </h1>
          <p className="mt-6 text-slate-600 font-semibold text-lg sm:text-xl max-w-2xl mx-auto">Seven core services, one connected workflow, all powered by AI to ship faster and learn faster.</p>
        </div>
      </section>

      {/* ALTERNATING SERVICES SECTIONS (LEFT & RIGHT SVG INTERACTION SECTIONS) */}
      <section className="bg-white relative">
        {servicesList.map((item, index) => {
          const IllustrationComponent = item.illustration;
          const isEven = index % 2 === 0;

          return (
            <div
              key={item.tag}
              className={`py-8 md:py-12 ${isEven ? "bg-white" : "bg-slate-50/30"
                }`}
            >
              <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid gap-12 lg:grid-cols-2 items-center">

                {/* Content Side */}
                <div className={`flex flex-col items-start ${isEven ? "lg:order-1 text-left" : "lg:order-2 text-left"}`}>

                  {/* Neobrutalist Speech-Bubble / Badge Tag */}
                  <div className="relative inline-block mb-6 select-none shrink-0">
                    <div className="absolute inset-0 bg-zinc-950 rounded-xl translate-x-1 translate-y-1" />
                    <div className="relative border-2 border-zinc-950 bg-[#fbbf24] text-zinc-950 px-4 py-1.5 font-doodle font-black text-xs sm:text-sm uppercase tracking-wider rounded-xl">
                      {item.tag}
                    </div>
                  </div>

                  {/* Headline */}
                  <h2 className="font-doodle font-black text-2xl sm:text-4xl lg:text-5xl text-zinc-950 leading-tight mb-6">
                    {item.title}
                  </h2>

                  {/* Detailed Description */}
                  <p className="text-slate-600 font-semibold text-sm sm:text-base leading-relaxed mb-6">
                    {item.desc}
                  </p>

                  {/* Bullet Points */}
                  <ul className="space-y-3 mb-8 w-full">
                    {item.points.map((p) => (
                      <li key={p} className="flex items-start gap-3 text-sm sm:text-base font-semibold text-slate-700">
                        <span className="text-[#10b981] font-bold text-xl leading-none mt-0.5 select-none">o</span>
                        <span className="leading-normal">{p}</span>
                      </li>
                    ))}
                  </ul>

                  {/* Splash Button Action */}
                  <div className="mt-2">
                    <Link
                      href="/contact"
                      className="inline-flex h-12 items-center justify-center px-8 rounded-full border-2 border-zinc-950 bg-zinc-950 text-white font-doodle font-black text-xs sm:text-sm hover:bg-white hover:text-zinc-950 transition-all duration-300 shadow-[3px_3px_0px_#fbbf24] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 select-none"
                    >
                      {item.btnLabel}
                    </Link>
                  </div>

                </div>

                {/* Illustration Side */}
                <div className={`flex items-center justify-center ${isEven ? "lg:order-2" : "lg:order-1"}`}>
                  <IllustrationComponent />
                </div>

              </div>
            </div>
          );
        })}
      </section>

      {/* HOW WE WORK (Process Section) */}
      <section className="py-24 border-b-4 border-zinc-950 bg-white relative overflow-hidden">
        {/* Grid paper mesh blueprint background */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#00000003_1px,transparent_1px),linear-gradient(to_bottom,#00000003_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none z-0" />

        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <div className="relative inline-flex items-center justify-center px-6 py-2 select-none font-doodle text-lg font-bold text-white tracking-wider uppercase animate-wiggle shrink-0 mb-4">
              <svg className="absolute inset-0 w-full h-full text-zinc-950 fill-current" viewBox="0 0 140 50" preserveAspectRatio="none">
                <path d="M5,5 C40,2 100,2 135,5 C138,15 138,35 135,45 C100,48 40,48 5,45 C2,35 2,15 5,5 Z" />
                <path d="M65,44 L70,51 L75,44 Z" />
              </svg>
              <span className="relative z-10 pt-0.5">Our Process</span>
            </div>

            <h2 className="mt-4 font-doodle text-4xl sm:text-5xl font-extrabold text-zinc-900 leading-tight">
              How We <span className="inline-block text-white mt-1 pb-1 sm:pb-2" style={{ WebkitTextStroke: '1.5px #09152e', textShadow: '2.5px 2.5px 0px #09152e' }}>Work</span>
            </h2>
            <p className="mt-6 text-slate-600 font-semibold text-lg">A transparent, step-by-step process to ensure your project's success from start to finish.</p>
          </div>

          <div className="mt-12 grid gap-8 grid-cols-1 md:grid-cols-3 lg:grid-cols-5 items-stretch">
            {processList.map((p, index) => (
              <div key={p.step} className="relative">
                <div className="group rounded-2xl bg-white border-2 border-zinc-950 p-6 h-full shadow-[4px_4px_0px_#09152e] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 transition-all duration-300 flex flex-col justify-start">
                  <div className="font-doodle text-4xl font-black text-zinc-950 mb-4 select-none pointer-events-none group-hover:rotate-6 transition-transform duration-300">{p.step}</div>
                  <h3 className="font-doodle font-black text-lg text-zinc-950 leading-tight">{p.title}</h3>
                  <p className="mt-3 text-sm text-slate-600 font-semibold leading-relaxed">{p.desc}</p>
                </div>
                {index < processList.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 -right-4.5 -translate-y-1/2 z-20 pointer-events-none select-none opacity-40">
                    <ArrowRight className="w-5 h-5 text-zinc-950" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Get Started bottom */}
      <section className="py-24 text-center bg-white relative">
        <Link href="/contact" className="inline-flex h-14 items-center justify-center px-10 rounded-full border-2 border-zinc-950 bg-zinc-950 text-white font-doodle font-black text-lg hover:bg-white hover:text-zinc-950 transition-all duration-300 shadow-[4px_4px_0px_#fbbf24] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 select-none">
          Get started <ArrowRight className="w-5 h-5 ml-2" />
        </Link>
      </section>
    </>
  );
}
