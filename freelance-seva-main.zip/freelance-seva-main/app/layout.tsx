import type { Metadata } from "next";
import { Inter, Sora, Patrick_Hand } from "next/font/google";
import "./globals.css";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import { ScrollProgress } from "@/components/ScrollProgress";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
});

const sora = Sora({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-display",
});

const patrickHand = Patrick_Hand({
  subsets: ["latin"],
  weight: "400",
  variable: "--font-doodle",
});

export const metadata: Metadata = {
  title: "FreelanceSeva — AI-Powered Digital Marketing Agency",
  description: "FreelanceSeva is an AI-powered digital marketing agency. Web design, Meta & Google Ads, SEO, social media and email marketing for startups & SMBs.",
  openGraph: {
    title: "FreelanceSeva — AI-Powered Digital Marketing Agency",
    description: "Web design, ads, SEO and social media — supercharged with AI.",
    type: "website",
  },
  icons: {
    icon: "/favicon.svg",
  },
  twitter: {
    card: "summary_large_image",
  },
};

export const viewport = {
  themeColor: "#3b6fe6",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${sora.variable} ${patrickHand.variable}`}>
      <body className="antialiased">
        <ScrollProgress />
        <Header />
        <main>{children}</main>
        <Footer />
        <WhatsAppButton />
      </body>
    </html>
  );
}
