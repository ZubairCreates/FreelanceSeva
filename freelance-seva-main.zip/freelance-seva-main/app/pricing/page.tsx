import Link from "next/link";
import { Check } from "lucide-react";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Pricing — FreelanceSeva Agency",
  description: "Transparent monthly packages for digital marketing services. Start at ₹8,000/month with no long-term contracts.",
};

const plans = [
  {
    name: "Starter", price: "₹8,000", popular: false,
    features: ["1 social media platform", "12 posts / month", "Basic ad campaign setup", "Monthly performance report", "Email support"],
  },
  {
    name: "Growth", price: "₹18,000", popular: true,
    features: ["Website + 2 platforms", "Meta Ads (₹5K budget mgmt)", "30 posts / month", "Weekly reporting", "On-page SEO basics", "Priority support"],
  },
  {
    name: "Premium", price: "₹35,000", popular: false,
    features: ["Full digital strategy", "Website + 3 platforms", "Meta + Google Ads", "Daily content", "SEO + email marketing", "Dedicated account manager"],
  },
];

export default function Pricing() {
  return (
    <>
      {/* Header section with sketchy theme */}
      <section className="bg-white border-b-4 border-zinc-950 py-24 relative overflow-hidden">
        {/* Grid paper mesh blueprint background */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#00000003_1px,transparent_1px),linear-gradient(to_bottom,#00000003_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none z-0" />
        
        <div className="relative mx-auto max-w-3xl px-4 text-center z-10">
          <div className="relative inline-flex items-center justify-center px-6 py-2 select-none font-doodle text-lg font-bold text-white tracking-wider uppercase animate-wiggle shrink-0 mb-4">
            <svg className="absolute inset-0 w-full h-full text-zinc-950 fill-current" viewBox="0 0 140 50" preserveAspectRatio="none">
              <path d="M5,5 C40,2 100,2 135,5 C138,15 138,35 135,45 C100,48 40,48 5,45 C2,35 2,15 5,5 Z" />
              <path d="M65,44 L70,51 L75,44 Z" />
            </svg>
            <span className="relative z-10 pt-0.5">Pricing</span>
          </div>

          <h1 className="mt-4 font-doodle text-4xl sm:text-6xl font-extrabold text-zinc-900 leading-tight">
            Simple, transparent <span className="inline-block text-white mt-1 pb-1 sm:pb-2" style={{ WebkitTextStroke: '1.5px #09152e', textShadow: '2.5px 2.5px 0px #09152e' }}>pricing.</span>
          </h1>
          <p className="mt-6 text-slate-600 font-semibold text-lg sm:text-xl">Pick a plan, cancel any month. Custom enterprise plans available.</p>
        </div>
      </section>

      {/* Pricing Cards Grid */}
      <section className="py-24 bg-white relative">
        <div className="mx-auto max-w-md lg:max-w-7xl px-4 grid gap-8 grid-cols-1 lg:grid-cols-3 items-stretch">
          {plans.map((p) => (
            <div
              key={p.name}
              className={`relative rounded-3xl p-8 border-2 border-zinc-950 bg-white flex flex-col justify-between transition-all duration-300 ${
                p.popular 
                  ? "shadow-[6px_6px_0px_#fbbf24] lg:translate-y-[-4px]" 
                  : "shadow-[4px_4px_0px_#09152e] hover:shadow-[6px_6px_0px_#09152e] hover:-translate-x-0.5 hover:-translate-y-0.5"
              }`}
            >
              {p.popular && (
                <span className="absolute -top-4.5 left-1/2 -translate-x-1/2 rounded-full border-2 border-zinc-950 bg-zinc-950 text-white font-doodle text-xs font-black uppercase tracking-wider px-5 py-1.5 shadow-[2px_2px_0px_#fbbf24] select-none pointer-events-none">
                  Most Popular
                </span>
              )}
              
              <div>
                <h3 className="font-doodle font-black text-2xl text-zinc-950">{p.name}</h3>
                
                <div className="mt-4 flex items-baseline gap-1 select-none pointer-events-none">
                  <span className="font-doodle text-4xl sm:text-5xl font-black text-zinc-950 leading-none">{p.price}</span>
                  <span className="text-slate-500 font-bold ml-1 text-sm">/mo</span>
                </div>
                
                <ul className="mt-8 space-y-4 text-sm font-semibold text-slate-600">
                  {p.features.map((f) => (
                    <li key={f} className="flex gap-3 items-center">
                      <svg className="w-5 h-5 text-zinc-950 shrink-0 select-none pointer-events-none" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                        <path d="M12,2 C6.5,2 2,6.5 2,12 C2,17.5 6.5,22 12,22 C17.5,22 22,17.5 22,12 L12,2" strokeLinecap="round" />
                      </svg>
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <Link
                href="/contact"
                className={`mt-10 inline-flex w-full justify-center h-14 items-center rounded-full border-2 border-zinc-950 font-doodle font-black text-lg transition-all duration-300 shadow-[4px_4px_0px_#09152e] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 select-none ${
                  p.popular
                    ? "bg-zinc-950 text-white shadow-[4px_4px_0px_#fbbf24]"
                    : "bg-white text-zinc-950 shadow-[4px_4px_0px_#09152e]"
                }`}
              >
                Get Started
              </Link>
            </div>
          ))}
        </div>
        
        <p className="mt-16 text-center text-base font-semibold text-slate-600">
          Need something custom?{" "}
          <Link href="/contact" className="text-zinc-950 font-bold underline decoration-zinc-950 decoration-2 underline-offset-4 hover:text-slate-700">Talk to us</Link>.
        </p>
      </section>
    </>
  );
}
