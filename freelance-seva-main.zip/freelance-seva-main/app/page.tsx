"use client";

import { useRef, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { motion, useScroll, useSpring } from "framer-motion";
import { ArrowRight, Sparkles, Rocket, Globe, Megaphone, Search, Mail, Share2, BarChart3, Check, Play, Phone } from "lucide-react";
import { TypewriterText } from "@/components/TypewriterText";
import { Counter } from "@/components/Counter";
import t1 from "@/assets/testimonial-1.jpg";
import t2 from "@/assets/testimonial-2.jpg";
import t3 from "@/assets/testimonial-3.jpg";
import t4 from "@/assets/testimonial-4.jpg";

const testimonials = [
  {
    img: t1,
    name: "Rahul Sharma",
    role: "MD, ShopEasy India",
    quote: "FreelanceSeva transformed our online presence completely. Our website traffic doubled within three months of redesign. The team was professional, prompt, and deeply understood what our business needed. Highly recommended for any serious business owner."
  },
  {
    img: t2,
    name: "Priya Mehta",
    role: "Founder, ThreadCraft",
    quote: "Our Shopify store went live ahead of schedule — and it looks incredible. The e-commerce store they built for us has already recovered its investment in the first month alone. Smooth process from start to finish."
  },
  {
    img: t3,
    name: "Anand Verma",
    role: "Owner, FitZone Gym",
    quote: "Our Google Ads ROI improved by 3x after switching to FreelanceSeva. They restructured our entire ad strategy. The reporting is transparent, the results are real, and the team genuinely cares about your growth."
  },
];

const services = [
  { icon: Globe, title: "Website Design & Development", desc: "We create fast, responsive, and visually compelling websites tailored to your brand. From landing pages to full business portals, our designs are built to engage visitors and drive conversions across all devices and screen sizes." },
  { icon: Rocket, title: "E-Commerce Solutions", desc: "Launch your online store with confidence. We build secure, scalable e-commerce platforms on Shopify, WooCommerce, and custom stacks — complete with product management, payment integration, and a smooth checkout experience your customers will trust." },
  { icon: Search, title: "SEO Services", desc: "Rank higher, get found faster. Our SEO strategies are data-driven and designed for long-term visibility. From technical audits to on-page optimization and link building, we help your website climb search engine rankings consistently." },
  { icon: Share2, title: "Social Media Marketing", desc: "Build a brand that resonates. We manage your social media presence across Facebook, Instagram, and Linkedin — crafting content that connects, engages your audience, and converts followers into loyal, paying customers over time." },
  { icon: Megaphone, title: "Google & Meta Ads", desc: "Get measurable results from every rupee spent. Our paid advertising specialists design targeted campaigns on Google and Meta platforms, optimizing for maximum ROI with precise audience targeting, compelling ad creatives, and continuous performance tracking." },
  { icon: Sparkles, title: "Logo & Brand Identity", desc: "First impressions matter. We design logos and brand identities that reflect your business values and stand apart in the market. From color palettes to typography, every element is crafted with purpose and consistency." },
  // { icon: BarChart3, title: "E-Commerce Management", desc: "We help sellers manage and grow their business on platforms like Meesho, Amazon, and Flipkart. From product listings and image optimization to catalog management, we handle everything professionally." },
];

const stats = [
  { value: "200+", label: "Projects Delivered" },
  { value: "150+", label: "Happy Clients" },
  { value: "5+", label: "Years of Experience" },
  { value: "98%", label: "Client Retention Rate" },
];

export default function Home() {
  const [activeFeature, setActiveFeature] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start center", "end center"]
  });

  const scaleY = useSpring(scrollYProgress, {
    damping: 30,
    stiffness: 100,
    restDelta: 0.001
  });

  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden bg-[#faf8f5] min-h-[90vh] flex items-center py-16 lg:py-24 px-4 sm:px-6 lg:px-8">

        {/* Faint blueprint grid background */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#00000003_1px,transparent_1px),linear-gradient(to_bottom,#00000003_1px,transparent_1px)] bg-[size:32px_32px] pointer-events-none z-0" />

        <div className="mx-auto max-w-7xl w-full relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">

          {/* Left Column: Premium Business & Conversion Copy */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="flex flex-col items-start text-left lg:col-span-7 space-y-8"
          >
            {/* Tagline / Sub-badge */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-amber-100 border-2 border-zinc-950 text-zinc-950 font-sans font-bold text-xs uppercase tracking-widest rounded-full shadow-[2.5px_2.5px_0px_rgba(0,0,0,1)] select-none">
              <Sparkles className="w-3.5 h-3.5 text-amber-500 fill-amber-500 animate-pulse" />
              <span>Premium Creative Agency</span>
            </div>

            {/* H1 Heading */}
            <h1 className="font-display text-4xl sm:text-6xl font-black text-zinc-950 leading-[1.08] tracking-tight">
              We Build Websites <br className="hidden sm:inline" />
              That <span className="relative inline-block text-white px-3.5 py-1 bg-zinc-950 rotate-[-1.5deg] shadow-[4px_4px_0px_#fbbf24] font-black tracking-wide">Grow</span> Businesses.
            </h1>

            {/* Subheading */}
            <p className="text-slate-600 text-lg sm:text-xl font-medium max-w-xl leading-relaxed">
              FreelanceSeva crafts custom high-performance websites, high-converting e-commerce stores, and high-ROI ad campaigns. Engineered to scale your brand and drive measurable revenue.
            </p>

            {/* CTA Section */}
            <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
              <Link
                href="/contact"
                className="inline-flex h-14 items-center justify-center px-8 rounded-full border-2 border-zinc-950 bg-zinc-950 text-white font-sans font-extrabold text-base hover:bg-[#faf8f5] hover:text-zinc-950 transition-all duration-300 shadow-[4px_4px_0px_#fbbf24] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 select-none w-full sm:w-auto text-center"
              >
                Get Free Strategy Call
              </Link>
              <Link
                href="/portfolio"
                className="inline-flex h-14 items-center justify-center px-8 rounded-full border-2 border-zinc-950 bg-white text-zinc-950 font-sans font-extrabold text-base hover:bg-zinc-950 hover:text-white transition-all duration-300 shadow-[4px_4px_0px_#09152e] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 select-none w-full sm:w-auto text-center"
              >
                View Our Work
              </Link>
            </div>

            {/* Trust signals & Accolades */}
            <div className="pt-8 border-t-2 border-dashed border-slate-200 w-full">
              <div className="grid grid-cols-3 gap-6 max-w-lg">
                <div>
                  <div className="font-display text-2xl sm:text-3xl font-black text-zinc-950">200+</div>
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Delivered</div>
                </div>
                <div>
                  <div className="font-display text-2xl sm:text-3xl font-black text-zinc-950">150+</div>
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Happy Clients</div>
                </div>
                <div>
                  <div className="font-display text-2xl sm:text-3xl font-black text-zinc-950">98%</div>
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Satisfaction</div>
                </div>
              </div>

              <div className="mt-6 flex items-center gap-2.5 text-sm font-bold text-slate-500 select-none">
                <Check className="w-5 h-5 text-emerald-500 stroke-[3] shrink-0" />
                <span>Trusted by startups & growing brands globally</span>
              </div>
            </div>

          </motion.div>

          {/* Right Column: Premium Dashboard Visual Illustration */}
          <div className="lg:col-span-5 relative flex items-center justify-center w-full min-h-[420px] select-none">
            {/* Soft decorative visual pulse circle behind mockup */}
            <div className="absolute w-72 h-72 rounded-full bg-amber-50/50 border border-amber-100 blur-2xl pointer-events-none" />

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative w-full max-w-[450px] aspect-square flex items-center justify-center"
            >
              {/* Floating Card A: SEO Traffic */}
              <motion.div
                animate={{ y: [0, -10, 0], x: [0, 6, 0] }}
                transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -top-4 -left-6 z-30 p-4 bg-white border-2 border-zinc-950 rounded-2xl shadow-[4px_4px_0px_#09152e] flex items-center gap-3"
              >
                <div className="w-10 h-10 rounded-xl bg-amber-100 border border-zinc-950 flex items-center justify-center shrink-0">
                  <BarChart3 className="w-5 h-5 text-zinc-950" />
                </div>
                <div>
                  <div className="text-[9px] font-extrabold text-slate-400 uppercase tracking-wider">SEO Traffic</div>
                  <div className="text-sm font-black text-zinc-950 flex items-center gap-1">
                    +142% <span className="text-[9px] text-emerald-500 font-bold">▲ Active</span>
                  </div>
                </div>
              </motion.div>

              {/* Floating Card B: ROI Booster */}
              <motion.div
                animate={{ y: [0, 12, 0], x: [0, -6, 0] }}
                transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 0.4 }}
                className="absolute -bottom-2 -right-6 z-30 p-4 bg-white border-2 border-zinc-950 rounded-2xl shadow-[4px_4px_0px_#fbbf24] flex items-center gap-3"
              >
                <div className="w-10 h-10 rounded-xl bg-emerald-100 border border-zinc-950 flex items-center justify-center shrink-0">
                  <Rocket className="w-5 h-5 text-zinc-950" />
                </div>
                <div>
                  <div className="text-[9px] font-extrabold text-slate-400 uppercase tracking-wider">ROI Boost</div>
                  <div className="text-sm font-black text-zinc-950">
                    3.8x <span className="text-[9px] text-emerald-500 font-bold">Growth</span>
                  </div>
                </div>
              </motion.div>

              {/* Main Mockup Screen Dashboard */}
              <motion.div
                animate={{ y: [0, -12, 0] }}
                transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
                className="relative w-full h-[320px] bg-white border-4 border-zinc-950 rounded-3xl shadow-[8px_8px_0px_#09152e] overflow-hidden flex flex-col z-20"
              >
                {/* Browser Top Bar */}
                <div className="h-10 border-b-2 border-zinc-950 bg-slate-50 px-4 flex items-center justify-between">
                  <div className="flex gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-400 border border-zinc-950" />
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-400 border border-zinc-950" />
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 border border-zinc-950" />
                  </div>
                  <div className="bg-white border border-zinc-950 text-[9px] text-slate-400 font-bold px-6 py-0.5 rounded-full">
                    freelanceseva.com
                  </div>
                  <div className="w-8" />
                </div>

                {/* Browser Content Dashboard */}
                <div className="flex-1 p-5 flex flex-col justify-between">
                  <div className="flex items-center justify-between border-b-2 border-dashed border-slate-100 pb-3">
                    <div>
                      <h3 className="font-display font-extrabold text-base text-zinc-950 leading-none">Business Growth</h3>
                      <p className="text-[9px] font-bold text-slate-400 mt-1">Live performance tracking</p>
                    </div>
                    <span className="px-2 py-0.5 bg-amber-400 border border-zinc-950 text-[8px] font-black rounded shadow-[1.5px_1.5px_0px_#000] rotate-[-2deg]">
                      Active
                    </span>
                  </div>

                  {/* Growing SVG Graph Chart */}
                  <div className="flex-1 flex items-end gap-3 pt-6 min-h-[100px] relative">
                    <svg className="w-full h-full overflow-visible" viewBox="0 0 200 80" preserveAspectRatio="none">
                      {/* Dash Guidelines */}
                      <line x1="0" y1="20" x2="200" y2="20" stroke="#f1f5f9" strokeWidth="1" strokeDasharray="3 3" />
                      <line x1="0" y1="50" x2="200" y2="50" stroke="#f1f5f9" strokeWidth="1" strokeDasharray="3 3" />

                      {/* Curved Growth Outline */}
                      <path
                        d="M 0 70 Q 50 65 100 45 T 200 12"
                        fill="none"
                        stroke="#09152e"
                        strokeWidth="4.5"
                        strokeLinecap="round"
                      />
                      <path
                        d="M 0 70 Q 50 65 100 45 T 200 12 L 200 80 L 0 80 Z"
                        fill="url(#gradient-chart-hero)"
                        opacity="0.15"
                      />
                      <defs>
                        <linearGradient id="gradient-chart-hero" x1="0%" y1="0%" x2="0%" y2="100%">
                          <stop offset="0%" stopColor="#fbbf24" />
                          <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
                        </linearGradient>
                      </defs>

                      {/* Pulser Point */}
                      <motion.circle
                        cx="200"
                        cy="12"
                        r="5.5"
                        fill="#fbbf24"
                        stroke="#09152e"
                        strokeWidth="2.5"
                        animate={{ scale: [1, 1.4, 1] }}
                        transition={{ duration: 2, repeat: Infinity }}
                      />
                    </svg>
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t-2 border-dashed border-slate-100">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                      <span className="text-[9px] font-bold text-slate-400">Marketing engines online</span>
                    </div>
                    <span className="text-[9px] font-extrabold text-zinc-950">98% Retention</span>
                  </div>
                </div>
              </motion.div>

              {/* Floating custom doodles */}
              {/* A. Starburst doodle */}
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 16, repeat: Infinity, ease: "linear" }}
                className="absolute -top-10 -right-6 z-10 w-12 h-12 pointer-events-none hidden sm:block"
              >
                <svg viewBox="0 0 24 24" className="w-full h-full fill-amber-400 stroke-zinc-950 stroke-[2]">
                  <path d="M12,2 L14.5,9.5 L24,12 L14.5,14.5 L12,22 L9.5,14.5 L2,12 L9.5,9.5 Z" />
                </svg>
              </motion.div>

              {/* B. Compass circle cross doodle */}
              <motion.div
                animate={{ y: [0, -6, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="absolute bottom-12 -left-12 z-10 w-10 h-10 pointer-events-none hidden sm:block"
              >
                <svg viewBox="0 0 24 24" className="w-full h-full fill-none stroke-zinc-950 stroke-[2]" strokeLinecap="round">
                  <path d="M12,2 L12,22 M2,12 L22,12" strokeDasharray="3 2" />
                  <circle cx="12" cy="12" r="5" fill="white" />
                </svg>
              </motion.div>
            </motion.div>
          </div>

        </div>
      </section>

      {/* TRUST BAR */}
      <section className="bg-white relative overflow-hidden">
        {/* Grid paper mesh blueprint background */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#00000003_1px,transparent_1px),linear-gradient(to_bottom,#00000003_1px,transparent_1px)] bg-[size:18px_18px] pointer-events-none z-0" />

        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-4 relative z-10">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((s) => (
              <div key={s.label} className="group relative flex flex-col items-center justify-center p-6 bg-white border-2 border-zinc-950 rounded-2xl shadow-[4px_4px_0px_#09152e] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 transition-all duration-300">
                <div className="font-doodle text-4xl sm:text-5xl font-black text-zinc-950 tracking-wide select-none pointer-events-none">
                  <Counter value={s.value} />
                </div>
                <div className="text-xs uppercase tracking-wider text-slate-500 font-doodle font-black mt-2 text-center select-none pointer-events-none">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section className="py-24 bg-[#fafafc] border-b border-border relative overflow-hidden">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-16 items-center mb-16">

            {/* Left side: Heading */}
            <div className="lg:col-span-7 flex flex-col items-start text-left max-w-2xl">
              {/* Custom Speech Bubble Badge */}
              <div className="relative inline-flex items-center justify-center px-6 py-2 select-none font-doodle text-lg font-bold text-white tracking-wider uppercase animate-wiggle shrink-0 mb-4">
                <svg className="absolute inset-0 w-full h-full text-zinc-950 fill-current" viewBox="0 0 140 50" preserveAspectRatio="none">
                  <path d="M5,5 C40,2 100,2 135,5 C138,15 138,35 135,45 C100,48 40,48 5,45 C2,35 2,15 5,5 Z" />
                  <path d="M65,44 L70,51 L75,44 Z" />
                </svg>
                <span className="relative z-10 pt-0.5">Services</span>
              </div>

              {/* Sketched Heading */}
              <h2 className="mt-4 font-doodle text-4xl sm:text-5xl font-extrabold text-zinc-900 leading-tight">
                Everything you need to <span className="inline-block text-white mt-1 pb-1 sm:pb-2" style={{ WebkitTextStroke: '1.5px #09152e', textShadow: '2.5px 2.5px 0px #09152e' }}>win online</span>
              </h2>
              <p className="mt-6 text-slate-600 text-lg font-medium leading-relaxed">
                From your first website to scaling ad campaigns — one team, one workflow, premium hand-crafted designs at every step.
              </p>
            </div>

            {/* Right side: High-converting Neobrutalist Widget */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="lg:col-span-5 w-full relative select-none"
            >
              {/* Soft decorative background circles */}
              <div className="absolute -top-6 -right-6 w-32 h-32 rounded-full bg-amber-100/50 border border-amber-200 blur-xl pointer-events-none" />
              <div className="absolute -bottom-6 -left-6 w-24 h-24 rounded-full bg-indigo-100/40 border border-indigo-200 blur-xl pointer-events-none" />

              {/* Main Card */}
              <div className="relative p-6 sm:p-8 bg-amber-50 border-4 border-zinc-950 rounded-3xl shadow-[6px_6px_0px_#09152e] hover:shadow-[8px_8px_0px_#09152e] hover:-translate-x-0.5 hover:-translate-y-0.5 transition-all duration-300 overflow-hidden group">

                {/* Floating Neobrutalist Tag Header */}
                <div className="absolute right-4 top-4 bg-zinc-950 text-white font-doodle text-[10px] uppercase font-black px-3.5 py-1 rounded-full border-2 border-zinc-950 rotate-[3deg] shadow-[2px_2px_0px_#fbbf24] z-10">
                  ⚡ 3x ROI
                </div>

                <h3 className="font-doodle text-2xl font-black text-zinc-950 mb-6">Our Agency Standard</h3>

                {/* List of custom neobrutalist perks */}
                <div className="space-y-4">
                  {[
                    { label: "100% Hand-Crafted Code", desc: "No slow templates or builders." },
                    { label: "SEO Optimized Structure", desc: "Built to rank high from day one." },
                    { label: "Dedicated Support", desc: "Real-time, direct developer updates." }
                  ].map((perk, i) => (
                    <div key={i} className="flex gap-4 items-start">
                      <span className="flex-shrink-0 grid place-items-center w-8 h-8 rounded-lg border-2 border-zinc-950 bg-emerald-100 shadow-[1.5px_1.5px_0px_#000] rotate-[-2deg] mt-0.5">
                        <Check className="w-4 h-4 text-zinc-950 stroke-[3]" />
                      </span>
                      <div>
                        <div className="font-doodle text-sm font-black text-zinc-950">{perk.label}</div>
                        <div className="text-slate-500 text-xs mt-0.5 font-medium">{perk.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Subtle visual doodles */}
                <motion.div
                  animate={{ rotate: [0, 360] }}
                  transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
                  className="absolute right-2 -bottom-2 w-10 h-10 text-amber-400 fill-amber-400 stroke-zinc-950 opacity-40 pointer-events-none group-hover:opacity-60 transition-opacity"
                >
                  <svg viewBox="0 0 24 24" className="w-full h-full stroke-[1.5]">
                    <path d="M12,2 L14.5,9.5 L24,12 L14.5,14.5 L12,22 L9.5,14.5 L2,12 L9.5,9.5 Z" />
                  </svg>
                </motion.div>
              </div>
            </motion.div>

          </div>

          {/* Timeline Container */}
          <div ref={containerRef} className="relative mt-20 max-w-5xl mx-auto pb-12">

            {/* Center tracking line (Center on desktop, Left-aligned at left-6 on mobile) */}
            <div className="absolute left-6 md:left-1/2 top-4 bottom-4 w-1 -translate-x-1/2 z-0">
              {/* Grey dashed background line */}
              <div className="absolute inset-y-0 left-0 w-1 border-l-4 border-dashed border-zinc-200" />

              {/* Active black solid line that grows on scroll */}
              <motion.div
                style={{ scaleY, originY: 0 }}
                className="absolute inset-y-0 left-0 w-1 border-l-4 border-zinc-950"
              />
            </div>

            {/* Services Timeline Items */}
            <div className="space-y-16 md:space-y-24 relative z-10">
              {services.map(({ icon: Icon, title, desc }, index) => {
                const isEven = index % 2 === 0;
                return (
                  <div key={title} className="relative flex items-center md:grid md:grid-cols-9 w-full pl-12 md:pl-0">

                    {/* Mobile timeline dot indicator (absolute on mobile) */}
                    <div className="absolute left-6 -translate-x-1/2 md:hidden z-20">
                      <motion.div
                        initial={{ scale: 0.8, rotate: -15 }}
                        whileInView={{ scale: 1, rotate: 0 }}
                        viewport={{ once: true, margin: "-100px" }}
                        className="w-10 h-10 rounded-full border-2 border-zinc-950 bg-amber-400 flex items-center justify-center shadow-[2px_2px_0px_rgba(0,0,0,1)]"
                      >
                        <Icon className="w-5 h-5 text-zinc-950" />
                      </motion.div>
                    </div>

                    {isEven ? (
                      <>
                        {/* Left side: Card */}
                        <motion.div
                          initial={{ x: -80, opacity: 0 }}
                          whileInView={{ x: 0, opacity: 1 }}
                          viewport={{ once: true, margin: "-100px" }}
                          transition={{ type: "spring", stiffness: 60, damping: 15 }}
                          className="col-span-4 w-full flex justify-end pr-0 md:pr-12"
                        >
                          <div className="group relative rounded-2xl border-2 border-zinc-950 bg-white p-8 shadow-[4px_4px_0px_#09152e] hover:shadow-[6px_6px_0px_#09152e] hover:-translate-x-0.5 hover:-translate-y-0.5 transition-all duration-300 flex flex-col items-start overflow-hidden w-full">

                            {/* Watermark loop doodle */}
                            <div className="absolute right-4 bottom-4 text-zinc-300 opacity-20 pointer-events-none group-hover:scale-115 group-hover:rotate-6 transition-transform duration-300">
                              <svg width="64" height="64" viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="4">
                                <path d="M10,20 C40,5 60,45 35,55 C15,60 10,35 45,30 C75,25 90,50 110,40" strokeLinecap="round" />
                              </svg>
                            </div>

                            {/* Mobile icon container */}
                            <span className="relative grid place-items-center w-12 h-12 text-zinc-950 font-bold mb-4 select-none pointer-events-none group-hover:rotate-6 transition-transform duration-300 md:hidden">
                              <svg className="absolute inset-0 w-full h-full text-zinc-950 fill-none" viewBox="0 0 50 50">
                                <path d="M25,5 C14,5 5,14 5,25 C5,36 14,45 25,45 C36,45 45,36 45,25 C45,14 36,5 25,5 C18,4 10,8 25,5" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                              </svg>
                              <Icon className="w-6 h-6 z-10" />
                            </span>

                            <h3 className="font-doodle text-2xl font-black text-zinc-950 mb-3">{title}</h3>
                            <p className="text-slate-600 text-sm/relaxed font-medium">{desc}</p>
                          </div>
                        </motion.div>

                        {/* Center Node (Desktop) */}
                        <div className="col-span-1 hidden md:flex justify-center items-center z-20">
                          <motion.div
                            initial={{ scale: 0, rotate: -45 }}
                            whileInView={{ scale: 1, rotate: 0 }}
                            viewport={{ once: true, margin: "-100px" }}
                            transition={{ type: "spring", stiffness: 100, damping: 12, delay: 0.15 }}
                            whileHover={{ scale: 1.1, rotate: 6 }}
                            className="w-14 h-14 rounded-full border-4 border-zinc-950 bg-amber-400 flex items-center justify-center shadow-[3px_3px_0px_#09152e] cursor-pointer"
                          >
                            <Icon className="w-6 h-6 text-zinc-950" />
                          </motion.div>
                        </div>

                        {/* Right side: Badge / Doodle */}
                        <motion.div
                          initial={{ x: 50, opacity: 0 }}
                          whileInView={{ x: 0, opacity: 1 }}
                          viewport={{ once: true, margin: "-100px" }}
                          transition={{ type: "spring", stiffness: 60, damping: 15, delay: 0.1 }}
                          className="col-span-4 w-full hidden md:flex justify-start pl-12"
                        >
                          <div className="flex flex-col items-center justify-center p-6 bg-amber-50/50 border-2 border-dashed border-zinc-950 rounded-2xl shadow-[3px_3px_0px_rgba(0,0,0,0.15)] select-none min-w-[160px]">
                            <div className="font-doodle text-5xl font-black text-zinc-300 tracking-wide mb-1">
                              {String(index + 1).padStart(2, '0')}
                            </div>
                            <div className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest text-center">
                              Service {String(index + 1).padStart(2, '0')}
                            </div>
                            <div className="mt-3 text-zinc-400 rotate-180">
                              <svg width="40" height="24" viewBox="0 0 40 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                                <path d="M5,12 L35,12 M25,5 L35,12 L25,19" />
                              </svg>
                            </div>
                          </div>
                        </motion.div>
                      </>
                    ) : (
                      <>
                        {/* Left side: Badge / Doodle */}
                        <motion.div
                          initial={{ x: -50, opacity: 0 }}
                          whileInView={{ x: 0, opacity: 1 }}
                          viewport={{ once: true, margin: "-100px" }}
                          transition={{ type: "spring", stiffness: 60, damping: 15, delay: 0.1 }}
                          className="col-span-4 w-full hidden md:flex justify-end pr-12"
                        >
                          <div className="flex flex-col items-center justify-center p-6 bg-amber-50/50 border-2 border-dashed border-zinc-950 rounded-2xl shadow-[3px_3px_0px_rgba(0,0,0,0.15)] select-none min-w-[160px]">
                            <div className="font-doodle text-5xl font-black text-zinc-300 tracking-wide mb-1">
                              {String(index + 1).padStart(2, '0')}
                            </div>
                            <div className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest text-center">
                              Service {String(index + 1).padStart(2, '0')}
                            </div>
                            <div className="mt-3 text-zinc-400">
                              <svg width="40" height="24" viewBox="0 0 40 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                                <path d="M5,12 L35,12 M25,5 L35,12 L25,19" />
                              </svg>
                            </div>
                          </div>
                        </motion.div>

                        {/* Center Node (Desktop) */}
                        <div className="col-span-1 hidden md:flex justify-center items-center z-20">
                          <motion.div
                            initial={{ scale: 0, rotate: -45 }}
                            whileInView={{ scale: 1, rotate: 0 }}
                            viewport={{ once: true, margin: "-100px" }}
                            transition={{ type: "spring", stiffness: 100, damping: 12, delay: 0.15 }}
                            whileHover={{ scale: 1.1, rotate: 6 }}
                            className="w-14 h-14 rounded-full border-4 border-zinc-950 bg-amber-400 flex items-center justify-center shadow-[3px_3px_0px_#09152e] cursor-pointer"
                          >
                            <Icon className="w-6 h-6 text-zinc-950" />
                          </motion.div>
                        </div>

                        {/* Right side: Card */}
                        <motion.div
                          initial={{ x: 80, opacity: 0 }}
                          whileInView={{ x: 0, opacity: 1 }}
                          viewport={{ once: true, margin: "-100px" }}
                          transition={{ type: "spring", stiffness: 60, damping: 15 }}
                          className="col-span-4 w-full flex justify-start pl-0 md:pl-12"
                        >
                          <div className="group relative rounded-2xl border-2 border-zinc-950 bg-white p-8 shadow-[4px_4px_0px_#09152e] hover:shadow-[6px_6px_0px_#09152e] hover:-translate-x-0.5 hover:-translate-y-0.5 transition-all duration-300 flex flex-col items-start overflow-hidden w-full">

                            {/* Watermark loop doodle */}
                            <div className="absolute right-4 bottom-4 text-zinc-300 opacity-20 pointer-events-none group-hover:scale-115 group-hover:rotate-6 transition-transform duration-300">
                              <svg width="64" height="64" viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="4">
                                <path d="M10,20 C40,5 60,45 35,55 C15,60 10,35 45,30 C75,25 90,50 110,40" strokeLinecap="round" />
                              </svg>
                            </div>

                            {/* Mobile icon container */}
                            <span className="relative grid place-items-center w-12 h-12 text-zinc-950 font-bold mb-4 select-none pointer-events-none group-hover:rotate-6 transition-transform duration-300 md:hidden">
                              <svg className="absolute inset-0 w-full h-full text-zinc-950 fill-none" viewBox="0 0 50 50">
                                <path d="M25,5 C14,5 5,14 5,25 C5,36 14,45 25,45 C36,45 45,36 45,25 C45,14 36,5 25,5 C18,4 10,8 25,5" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                              </svg>
                              <Icon className="w-6 h-6 z-10" />
                            </span>

                            <h3 className="font-doodle text-2xl font-black text-zinc-950 mb-3">{title}</h3>
                            <p className="text-slate-600 text-sm/relaxed font-medium">{desc}</p>
                          </div>
                        </motion.div>
                      </>
                    )}

                  </div>
                );
              })}
            </div>

          </div>
        </div>
      </section>

      {/* WEB DESIGN DOODLE SECTION (Diamond Startup Scene) */}
      <section className="py-24 overflow-hidden bg-white border-t border-b border-border relative">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid gap-16 lg:grid-cols-2 items-center relative">

          {/* Background grid accents */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#f1f5f9_1px,transparent_1px),linear-gradient(to_bottom,#f1f5f9_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-60 pointer-events-none" />

          <div className="relative z-10 flex flex-col items-start max-w-xl">
            {/* Custom Speech Bubble Badge */}
            <div className="relative inline-flex items-center justify-center px-6 py-2 select-none font-doodle text-lg font-bold text-white tracking-wider uppercase animate-wiggle shrink-0">
              <svg className="absolute inset-0 w-full h-full text-zinc-950 fill-current" viewBox="0 0 140 50" preserveAspectRatio="none">
                <path d="M5,5 C40,2 100,2 135,5 C138,15 138,35 135,45 C100,48 40,48 5,45 C2,35 2,15 5,5 Z" />
                <path d="M65,44 L70,51 L75,44 Z" />
              </svg>
              <span className="relative z-10 pt-0.5">Philosophy</span>
            </div>

            {/* Sketched Heading */}
            <h2 className="mt-8 font-doodle text-4xl sm:text-5xl font-extrabold text-zinc-900 leading-tight tracking-wide">
              Engineered to Perform. <br className="hidden sm:inline" />
              {/* <span className="inline-block text-white mt-2 pb-2 sm:pb-3" style={{ WebkitTextStroke: '2px #09152e', textShadow: '3px 3px 0px #09152e' }}>
                Bespoke, never off the shelf.
              </span> */}
            </h2>

            {/* Interactive Features List */}
            <div className="mt-8 space-y-2.5 w-full">
              {[
                { title: "Performance-first custom React & Next.js" },
                { title: "High-conversion bespoke interface designs" },
                { title: "SEO-ready semantic architectures" },
              ].map((item, index) => {
                const isActive = activeFeature === index;
                return (
                  <div
                    key={item.title}
                    onClick={() => setActiveFeature(index)}
                    className={`group/feat cursor-pointer flex gap-3 p-3 rounded-xl border-2 transition-all duration-300 w-full text-left relative ${isActive
                      ? "bg-amber-50 border-zinc-950 shadow-[3px_3px_0px_#09152e] translate-x-1.5"
                      : "bg-white border-zinc-200 hover:border-zinc-300 hover:translate-x-0.5"
                      }`}
                  >
                    {/* Circle number icon */}
                    <div className="shrink-0 select-none">
                      <span className={`flex items-center justify-center w-7 h-7 rounded-full border-2 border-zinc-950 text-xs font-black transition-all duration-300 ${isActive ? "bg-zinc-950 text-white scale-110 shadow-[1px_1px_0px_rgba(0,0,0,0.15)]" : "bg-white text-zinc-400 border-zinc-300"
                        }`}>
                        {index + 1}
                      </span>
                    </div>

                    <div className="flex flex-col justify-center w-full">
                      <h4 className="text-zinc-900 font-extrabold text-sm sm:text-base leading-tight transition-colors duration-200">
                        {item.title}
                      </h4>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Paragraph Description */}
            {/* <p className="mt-6 text-slate-600 text-sm sm:text-base/relaxed font-medium text-left w-full">
              We build custom high-performance web architectures that load instantly and rank high. Click a pillar above to see our engines in action:
            </p> */}

            {/* Dynamic Specifications & Instructions Box */}
            <div className="mt-4 p-4 rounded-xl border-2 border-zinc-950 bg-amber-50/70 shadow-[3px_3px_0px_#09152e] w-full transition-all duration-300 text-left">
              <div className="flex items-center gap-2 mb-1.5">
                <span className="flex h-2 w-2 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <span className="text-[10px] font-black uppercase tracking-widest text-zinc-950">Engine Specs & Guidelines:</span>
              </div>
              <p className="text-slate-600 text-xs sm:text-sm font-semibold leading-relaxed">
                {activeFeature === 0 && "Built using modular Next.js architecture to achieve near-zero latency, absolute speed, and a perfect Lighthouse rating."}
                {activeFeature === 1 && "Painstakingly optimized conversion funnels, clear interactive elements, and premium layouts designed to scale your revenue."}
                {activeFeature === 2 && "Perfect schema markups, clean JSON-LD indexation, and highly-semantic layouts built to claim page-one positions on Google."}
              </p>
            </div>

            {/* Premium CTA Button */}
            <div className="mt-10">
              <Link
                href="/services"
                className="inline-flex h-14 items-center justify-center px-8 rounded-full border-2 border-zinc-950 bg-zinc-950 text-white font-sans font-extrabold text-base hover:bg-white hover:text-zinc-950 transition-all duration-300 shadow-[4px_4px_0px_#fbbf24] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 select-none"
              >
                Explore Custom Engineering
              </Link>
            </div>
          </div>

          {/* Right column premium tilted-diamond startup illustration */}
          <div className="relative flex items-center justify-center w-full z-10">
            <div className="relative w-full max-w-[500px] aspect-square flex items-center justify-center animate-float z-20">
              <svg className="w-full h-full" viewBox="0 0 500 500" fill="none" xmlns="http://www.w3.org/2000/svg">

                {/* 1. Neobrutalist Browser Background Shadow */}
                <rect x="58" y="88" width="400" height="340" rx="24" fill="#09152e" />

                {/* 2. Main Browser Window Card */}
                <rect x="50" y="80" width="400" height="340" rx="24" fill="white" stroke="#09152e" strokeWidth="4" />

                {/* 3. Browser Window Chrome Header */}
                <line x1="50" y1="125" x2="450" y2="125" stroke="#09152e" strokeWidth="4" />

                {/* Mac window action dots */}
                <circle cx="85" cy="102" r="6" fill="#ef4444" stroke="#09152e" strokeWidth="2" />
                <circle cx="105" cy="102" r="6" fill="#fbbf24" stroke="#09152e" strokeWidth="2" />
                <circle cx="125" cy="102" r="6" fill="#10b981" stroke="#09152e" strokeWidth="2" />

                {/* Browser address bar */}
                <rect x="160" y="92" width="240" height="20" rx="10" fill="#f1f5f9" stroke="#09152e" strokeWidth="2" />
                <circle cx="172" cy="102" r="3" fill="#94a3b8" />
                <line x1="182" y1="102" x2="230" y2="102" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round" />

                {/* 4. Inside Dashboard: Dynamic Grid Layout */}
                <g opacity="0.15">
                  <line x1="50" y1="180" x2="450" y2="180" stroke="#09152e" strokeWidth="1" strokeDasharray="4 4" />
                  <line x1="50" y1="240" x2="450" y2="240" stroke="#09152e" strokeWidth="1" strokeDasharray="4 4" />
                  <line x1="50" y1="300" x2="450" y2="300" stroke="#09152e" strokeWidth="1" strokeDasharray="4 4" />
                  <line x1="50" y1="360" x2="450" y2="360" stroke="#09152e" strokeWidth="1" strokeDasharray="4 4" />
                  <line x1="210" y1="125" x2="210" y2="420" stroke="#09152e" strokeWidth="1" strokeDasharray="4 4" />
                </g>

                {/* 5. Circular Speed Gauge (Left Panel) */}
                <g className="origin-[130px_270px] transition-transform duration-300" style={{ transform: activeFeature === 0 ? "scale(1.05)" : "scale(1)" }}>
                  <circle cx="130" cy="270" r="50" fill="none" stroke="#f1f5f9" strokeWidth="12" />
                  {/* Gauge indicator ring */}
                  <circle
                    cx="130"
                    cy="270"
                    r="50"
                    fill="none"
                    stroke={activeFeature === 0 ? "#10b981" : "#94a3b8"}
                    strokeWidth="12"
                    strokeDasharray="314"
                    strokeDashoffset={activeFeature === 0 ? "10" : activeFeature === 1 ? "110" : "80"}
                    strokeLinecap="round"
                    transform="rotate(-90 130 270)"
                    style={{ transition: "stroke-dashoffset 0.6s cubic-bezier(0.16, 1, 0.3, 1), stroke 0.3s" }}
                  />
                  <text x="130" y="265" fontFamily="var(--font-doodle, sans-serif)" fontSize="26" fontWeight="900" fill="#09152e" textAnchor="middle">
                    {activeFeature === 0 ? "100" : activeFeature === 1 ? "92" : "98"}
                  </text>
                  <text x="130" y="285" fontFamily="sans-serif" fontSize="10" fontWeight="800" fill="#64748b" textAnchor="middle" letterSpacing="1">SPEED</text>
                </g>

                {/* 6. Metrics and Progress Indicators (Right Panel) */}
                <g>
                  {/* Performance Label */}
                  <text x="220" y="170" fontFamily="sans-serif" fontSize="11" fontWeight="800" fill="#09152e" letterSpacing="0.5">PERFORMANCE ENGINE</text>

                  {/* Performance metric row 1 */}
                  <rect x="220" y="185" width="190" height="12" rx="6" fill="#f1f5f9" stroke="#09152e" strokeWidth="2" />
                  <rect
                    x="220"
                    y="185"
                    width={activeFeature === 0 ? "185" : "130"}
                    height="12"
                    rx="6"
                    fill={activeFeature === 0 ? "#fbbf24" : "#cbd5e1"}
                    stroke="#09152e"
                    strokeWidth="2"
                    style={{ transition: "width 0.6s cubic-bezier(0.16, 1, 0.3, 1), fill 0.3s" }}
                  />

                  {/* Performance metric row 2 */}
                  <text x="220" y="225" fontFamily="sans-serif" fontSize="11" fontWeight="800" fill="#09152e" letterSpacing="0.5">SEO DOMINANCE</text>
                  <rect x="220" y="240" width="190" height="12" rx="6" fill="#f1f5f9" stroke="#09152e" strokeWidth="2" />
                  <rect
                    x="220"
                    y="240"
                    width={activeFeature === 2 ? "185" : "120"}
                    height="12"
                    rx="6"
                    fill={activeFeature === 2 ? "#10b981" : "#cbd5e1"}
                    stroke="#09152e"
                    strokeWidth="2"
                    style={{ transition: "width 0.6s cubic-bezier(0.16, 1, 0.3, 1), fill 0.3s" }}
                  />

                  {/* Performance metric row 3 */}
                  <text x="220" y="280" fontFamily="sans-serif" fontSize="11" fontWeight="800" fill="#09152e" letterSpacing="0.5">LCP SPEED RATING</text>
                  <rect x="220" y="295" width="190" height="12" rx="6" fill="#f1f5f9" stroke="#09152e" strokeWidth="2" />
                  <rect
                    x="220"
                    y="295"
                    width={activeFeature === 1 ? "185" : "140"}
                    height="12"
                    rx="6"
                    fill={activeFeature === 1 ? "#38bdf8" : "#cbd5e1"}
                    stroke="#09152e"
                    strokeWidth="2"
                    style={{ transition: "width 0.6s cubic-bezier(0.16, 1, 0.3, 1), fill 0.3s" }}
                  />
                </g>

                {/* 7. Floating Neobrutalist Badges */}

                {/* A. Core Web Vitals (Bottom Right) */}
                <g
                  className="animate-[float_5s_ease-in-out_infinite] origin-[340px_350px]"
                  style={{ transform: activeFeature === 1 ? "scale(1.08)" : "scale(1)", transition: "transform 0.3s" }}
                >
                  <rect x="288" y="338" width="140" height="60" rx="14" fill="#09152e" />
                  <rect
                    x="280"
                    y="330"
                    width="140" height="60" rx="14"
                    fill={activeFeature === 1 ? "#10b981" : "#f8fafc"}
                    stroke="#09152e"
                    strokeWidth="3"
                    style={{ transition: "fill 0.3s" }}
                  />
                  <text x="350" y="354" fontFamily="sans-serif" fontSize="10" fontWeight="950" fill={activeFeature === 1 ? "white" : "#64748b"} textAnchor="middle" letterSpacing="0.5">CORE WEB VITALS</text>
                  <text x="350" y="378" fontFamily="sans-serif" fontSize="16" fontWeight="950" fill={activeFeature === 1 ? "#fbbf24" : "#09152e"} textAnchor="middle" letterSpacing="1">★ PASSED ★</text>
                </g>

                {/* B. Next.js / React (Top Left) */}
                <g
                  className="animate-[float_6s_ease-in-out_infinite_1s] origin-[100px_60px]"
                  style={{ transform: activeFeature === 0 ? "scale(1.08)" : "scale(1)", transition: "transform 0.3s" }}
                >
                  <rect x="24" y="44" width="130" height="42" rx="12" fill="#09152e" />
                  <rect
                    x="18"
                    y="38"
                    width="130" height="42" rx="12"
                    fill={activeFeature === 0 ? "#fbbf24" : "white"}
                    stroke="#09152e"
                    strokeWidth="3"
                    style={{ transition: "fill 0.3s" }}
                  />
                  <circle cx="36" cy="59" r="5" fill="#10b981" />
                  <text x="49" y="63" fontFamily="sans-serif" fontSize="12" fontWeight="900" fill="#09152e" letterSpacing="0.5">REACT NEXT</text>
                </g>

                {/* C. 100% Bespoke Badge (Bottom Left) */}
                <g
                  className="animate-[float_4s_ease-in-out_infinite_2s] origin-[80px_360px]"
                  style={{ transform: activeFeature === 2 ? "scale(1.08)" : "scale(1)", transition: "transform 0.3s" }}
                >
                  <rect x="28" y="358" width="124" height="46" rx="12" fill="#09152e" />
                  <rect
                    x="20"
                    y="350"
                    width="124" height="46" rx="12"
                    fill={activeFeature === 2 ? "#fbbf24" : "white"}
                    stroke="#09152e"
                    strokeWidth="3"
                    style={{ transition: "fill 0.3s" }}
                  />
                  <text x="82" y="378" fontFamily="var(--font-doodle, sans-serif)" fontSize="13" fontWeight="900" fill="#09152e" textAnchor="middle" letterSpacing="0.5">100% BESPOKE</text>
                </g>

                {/* 8. DYNAMIC FLAVOR GRAPHIC FLOATING OVERLAYS */}

                {/* Lighthouse Score Card (Active for Speed: 0) */}
                {activeFeature === 0 && (
                  <motion.g
                    initial={{ opacity: 0, scale: 0.8, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    transition={{ type: "spring", stiffness: 120, damping: 10 }}
                    className="origin-[380px_160px]"
                  >
                    <rect x="290" y="140" width="130" height="50" rx="12" fill="#09152e" />
                    <rect x="282" y="132" width="130" height="50" rx="12" fill="white" stroke="#09152e" strokeWidth="2.5" />
                    <circle cx="308" cy="157" r="10" fill="#10b981" />
                    <text x="308" y="161" fontFamily="sans-serif" fontSize="10" fontWeight="900" fill="white" textAnchor="middle">✓</text>
                    <text x="328" y="153" fontFamily="sans-serif" fontSize="8" fontWeight="800" fill="#64748b">LIGHTHOUSE</text>
                    <text x="328" y="166" fontFamily="sans-serif" fontSize="10" fontWeight="950" fill="#09152e">100/100</text>
                  </motion.g>
                )}

                {/* Conversion Lift Card (Active for Conversion: 1) */}
                {activeFeature === 1 && (
                  <motion.g
                    initial={{ opacity: 0, scale: 0.8, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    transition={{ type: "spring", stiffness: 120, damping: 10 }}
                    className="origin-[130px_170px]"
                  >
                    <rect x="70" y="145" width="130" height="52" rx="12" fill="#09152e" />
                    <rect x="62" y="137" width="130" height="52" rx="12" fill="#38bdf8" stroke="#09152e" strokeWidth="2.5" />
                    <text x="127" y="154" fontFamily="sans-serif" fontSize="8" fontWeight="900" fill="#09152e" textAnchor="middle">CONVERSION RATE</text>
                    <text x="127" y="172" fontFamily="sans-serif" fontSize="13" fontWeight="950" fill="white" textAnchor="middle">+4.8% LIFT</text>
                  </motion.g>
                )}

                {/* Google Search Rank Badge (Active for SEO: 2) */}
                {activeFeature === 2 && (
                  <motion.g
                    initial={{ opacity: 0, scale: 0.8, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    transition={{ type: "spring", stiffness: 120, damping: 10 }}
                    className="origin-[350px_160px]"
                  >
                    <rect x="290" y="140" width="130" height="50" rx="12" fill="#09152e" />
                    <rect x="282" y="132" width="130" height="50" rx="12" fill="#fbbf24" stroke="#09152e" strokeWidth="2.5" />
                    <text x="347" y="151" fontFamily="sans-serif" fontSize="8" fontWeight="900" fill="#09152e" textAnchor="middle">GOOGLE SERP</text>
                    <text x="347" y="167" fontFamily="sans-serif" fontSize="12" fontWeight="950" fill="#09152e" textAnchor="middle">★ RANK #1 ★</text>
                  </motion.g>
                )}

              </svg>
            </div>
          </div>

        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="py-24 bg-white border-t border-border relative">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">

          <div className="max-w-2xl mb-16">
            {/* Custom Speech Bubble Badge */}
            <div className="relative inline-flex items-center justify-center px-6 py-2 select-none font-doodle text-lg font-bold text-white tracking-wider uppercase animate-wiggle shrink-0 mb-4">
              <svg className="absolute inset-0 w-full h-full text-zinc-950 fill-current" viewBox="0 0 140 50" preserveAspectRatio="none">
                <path d="M5,5 C40,2 100,2 135,5 C138,15 138,35 135,45 C100,48 40,48 5,45 C2,35 2,15 5,5 Z" />
                <path d="M65,44 L70,51 L75,44 Z" />
              </svg>
              <span className="relative z-10 pt-0.5">Testimonials</span>
            </div>

            {/* Sketched Heading */}
            <h2 className="mt-4 font-doodle text-4xl sm:text-5xl font-extrabold text-zinc-900 leading-tight">
              Watch our clients <span className="inline-block text-white mt-1 pb-1 sm:pb-2" style={{ WebkitTextStroke: '1.5px #09152e', textShadow: '2.5px 2.5px 0px #09152e' }}>genuine feedback</span>
            </h2>
            <p className="mt-6 text-slate-600 text-lg font-medium">
              Hear directly from our change-makers and partners what it feels like to achieve real impact.
            </p>
          </div>

          <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {testimonials.map((t) => (
              <div key={t.name} className="group relative flex flex-col rounded-2xl border-2 border-zinc-950 bg-white p-8 shadow-[4px_4px_0px_#09152e] hover:shadow-[6px_6px_0px_#09152e] hover:-translate-x-0.5 hover:-translate-y-0.5 transition-all duration-300 overflow-hidden min-h-[260px]">

                {/* Hand-drawn watermark double quotes SVG */}
                <div className="absolute right-4 bottom-4 text-zinc-200 opacity-30 pointer-events-none group-hover:scale-110 transition-transform duration-300">
                  <svg width="48" height="48" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M14,17 H17 L19,13 V7 H13 V13 H16 L14,17 M6,17 H9 L11,13 V7 H5 V13 H8 L6,17 Z" />
                  </svg>
                </div>

                <div className="flex items-center gap-4 mb-4 z-10">
                  <div className="relative w-12 h-12 rounded-full overflow-hidden border-2 border-zinc-950 shrink-0">
                    <Image
                      src={t.img}
                      alt={t.name}
                      fill
                      sizes="48px"
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <div className="font-doodle font-black text-lg text-zinc-950 leading-none">{t.name}</div>
                    <div className="text-xs text-slate-500 font-semibold mt-1">{t.role}</div>
                  </div>
                </div>

                <p className="text-sm/relaxed text-slate-600 font-semibold italic mt-4 z-10">
                  "{t.quote}"
                </p>

                {/* Custom Outlined Sparkles Rating */}
                <div className="mt-auto pt-6 flex gap-1 text-[#fbbf24] z-10">
                  {[...Array(5)].map((_, i) => (
                    <svg key={i} className="w-4 h-4 fill-current stroke-zinc-950 stroke-1.5 shrink-0 select-none pointer-events-none" viewBox="0 0 24 24">
                      <path d="M12,2 L14.5,9.5 L24,12 L14.5,14.5 L12,22 L9.5,14.5 L2,12 L9.5,9.5 Z" />
                    </svg>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 relative overflow-hidden">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10">

          {/* Main Hand-drawn CTA Card Container */}
          <div className="relative overflow-hidden rounded-3xl border-4 border-zinc-950 bg-amber-50 p-10 sm:p-14 text-center text-zinc-950 shadow-[8px_8px_0px_#09152e] z-20">
            {/* Grid paper mesh blueprint background inside the card */}
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#00000003_1px,transparent_1px),linear-gradient(to_bottom,#00000003_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none z-0" />

            {/* Floating Starburst - Top Left */}
            <div className="absolute top-6 left-6 opacity-75 z-10 pointer-events-none hidden sm:block animate-pulse">
              <svg width="40" height="40" viewBox="0 0 40 40" fill="none" stroke="#09152e" strokeWidth="2" strokeLinecap="round">
                <path d="M20,5 L20,35 M5,20 L35,20" strokeDasharray="3 2" />
                <path d="M10,10 L30,30 M30,10 L10,30" />
              </svg>
            </div>

            {/* Floating Sparkle Star - Bottom Right */}
            <div className="absolute bottom-6 right-6 opacity-75 z-10 pointer-events-none hidden sm:block animate-pulse">
              <svg width="40" height="40" viewBox="0 0 24 24" fill="#fbbf24" stroke="#09152e" strokeWidth="2">
                <path d="M12,2 L14.5,9.5 L24,12 L14.5,14.5 L12,22 L9.5,14.5 L2,12 L9.5,9.5 Z" />
              </svg>
            </div>

            {/* Hand-drawn Loop Arrow - Left Center (pointing to buttons) */}
            <div className="absolute left-6 top-1/2 -translate-y-1/2 opacity-75 z-10 pointer-events-none hidden md:block animate-[wiggle_5s_infinite]">
              <svg width="80" height="60" viewBox="0 0 80 60" fill="none" stroke="#09152e" strokeWidth="2.2" strokeLinecap="round">
                <path d="M10,10 Q35,40 50,20 C60,5 40,5 25,20 T70,45" />
                <path d="M60,42 L70,45 L68,36" />
              </svg>
            </div>

            {/* Custom Sketched Animated Rocket SVG */}
            <div className="relative inline-flex items-center justify-center w-20 h-20 mb-6 select-none pointer-events-none animate-float">
              <svg className="w-full h-full" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                {/* Smoke ring trail */}
                <circle cx="32" cy="58" r="8" fill="white" stroke="#09152e" strokeWidth="2" />
                <circle cx="48" cy="58" r="8" fill="white" stroke="#09152e" strokeWidth="2" />

                {/* Rocket core body */}
                <path d="M26,38 C32,24 48,24 54,38 L48,60 C38,62 34,62 32,60 Z" fill="#fbbf24" stroke="#09152e" strokeWidth="2.5" />
                {/* Red tip */}
                <path d="M36,27 C38,20 42,20 44,27 C42,22 38,22 36,27 Z" fill="#ef4444" stroke="#09152e" strokeWidth="2" />
                {/* Window */}
                <circle cx="40" cy="40" r="5" fill="white" stroke="#09152e" strokeWidth="2" />
                {/* Rocket side wings */}
                <path d="M28,50 L18,58 C16,60 20,62 24,60 L28,54" fill="#18181b" stroke="#09152e" strokeWidth="2" />
                <path d="M52,50 L62,58 C64,60 60,62 56,60 L52,54" fill="#18181b" stroke="#09152e" strokeWidth="2" />
                {/* Burn trail lines */}
                <path d="M36,63 L34,70 M40,64 L40,73 M44,63 L46,70" stroke="#09152e" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </div>

            {/* Slanted banner highlight style headline */}
            <h2 className="font-doodle text-3xl sm:text-5xl font-black text-zinc-950 tracking-wide uppercase leading-tight max-w-2xl mx-auto">
              Ready to give your <br className="hidden sm:inline" />
              <span className="inline-block text-white mt-2 px-6 py-2 bg-zinc-950 rotate-[-1.5deg] shadow-[4px_4px_0px_#00000020] text-2xl sm:text-4xl">
                brand the digital edge?
              </span>
            </h2>

            {/* Description */}
            <p className="mt-8 text-slate-600 text-base sm:text-lg font-semibold max-w-xl mx-auto leading-relaxed">
              Get a free consultation and a personalised growth audit — no strings attached.
            </p>

            {/* Cohesive hand-crafted outlined buttons */}
            <div className="mt-10 flex flex-col sm:flex-row justify-center items-center gap-6 relative z-10">
              <Link href="/contact" className="inline-flex h-14 items-center justify-center px-8 rounded-full border-2 border-zinc-950 bg-zinc-950 text-white font-doodle font-black text-lg hover:bg-white hover:text-zinc-950 transition-all duration-300 shadow-[4px_4px_0px_#fbbf24] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 select-none w-full sm:w-auto">
                Start Your Project Today <ArrowRight className="w-5 h-5 ml-2" />
              </Link>

              <Link href="tel:+916397801840" className="inline-flex h-14 items-center justify-center px-8 rounded-full border-2 border-zinc-950 bg-white text-zinc-950 font-doodle font-black text-lg hover:bg-zinc-950 hover:text-white transition-all duration-300 shadow-[4px_4px_0px_#09152e] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 select-none w-full sm:w-auto">
                <Phone className="w-5 h-5 mr-2" /> Call Now
              </Link>
            </div>
          </div>

        </div>
      </section>
    </>
  );
}
